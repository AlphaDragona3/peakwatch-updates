"""Protocol v1 HTTPS updater. Applies only before monitoring starts."""
import hashlib, io, json, os, re, shutil, stat, tempfile, zipfile
from pathlib import Path, PurePosixPath
from urllib.parse import urlsplit
from urllib.request import Request, urlopen
BASE=Path(__file__).resolve().parent
DATA=Path(os.environ.get('LOCALAPPDATA',str(Path.home())))/'PeakWatch'
ALLOWED={'panels.py','core.py','peakwatch.py','updater.py','launcher.py','START.bat','requirements.txt','README_MN.txt','VERSION'}
REQUIRED={'panels.py','core.py','peakwatch.py','updater.py','launcher.py','START.bat','requirements.txt','VERSION'}
MAX_ZIP=10*1024*1024
DEFAULT_FEED='https://raw.githubusercontent.com/AlphaDragona3/peakwatch-updates/main/manifest.json'

def version(value):
    if not isinstance(value,str) or not re.fullmatch(r'\d+\.\d+\.\d+',value):raise ValueError('Version must be x.y.z')
    return tuple(int(x) for x in value.split('.'))

def local_version(base=BASE):return (base/'VERSION').read_text().strip()

def settings():
    DATA.mkdir(parents=True,exist_ok=True)
    path=DATA/'update_settings.json'
    result=json.loads(path.read_text(encoding='utf-8')) if path.exists() else {'manifest_url':DEFAULT_FEED,'automatic':True}
    if result.get('automatic',True) and not result.get('manifest_url','').strip():result['manifest_url']=DEFAULT_FEED
    return result

def write_settings(value):
    DATA.mkdir(parents=True,exist_ok=True)
    path=DATA/'update_settings.json';tmp=path.with_suffix('.tmp');tmp.write_text(json.dumps(value,ensure_ascii=False,indent=2),encoding='utf-8');tmp.replace(path)

def https_url(url):
    p=urlsplit(url)
    if p.scheme!='https' or not p.hostname or p.username or p.password:raise ValueError('An HTTPS URL without credentials is required')
    return url

def fetch(url,limit):
    https_url(url)
    with urlopen(Request(url,headers={'User-Agent':'PeakWatch-Updater/1','Cache-Control':'no-cache'}),timeout=12) as response:
        https_url(response.geturl())
        if response.headers.get('Content-Length') and int(response.headers['Content-Length'])>limit:raise ValueError('Download too large')
        blob=response.read(limit+1)
    if len(blob)>limit:raise ValueError('Download too large')
    return blob

def unpack_package(blob, expected_version):
    """Never extract arbitrary paths; return only explicitly allowed code bytes."""
    version(expected_version);result={};total=0
    with zipfile.ZipFile(io.BytesIO(blob)) as archive:
        for info in archive.infolist():
            if info.is_dir():continue
            p=PurePosixPath(info.filename)
            if '\\' in info.filename or p.is_absolute() or '..' in p.parts:raise ValueError('Unsafe ZIP path')
            if len(p.parts)>2:raise ValueError('ZIP may have at most one root folder')
            name=p.name
            if name not in ALLOWED:raise ValueError('Unapproved update file: '+name)
            if name in result:raise ValueError('Duplicate update file')
            if stat.S_ISLNK(info.external_attr>>16):raise ValueError('ZIP symlink rejected')
            total+=info.file_size
            if total>MAX_ZIP:raise ValueError('Expanded package too large')
            result[name]=archive.read(info)
    if not REQUIRED.issubset(result):raise ValueError('Incomplete update package')
    if result['VERSION'].decode().strip()!=expected_version:raise ValueError('Package version mismatch')
    return result

def recover(base=BASE):
    """If interrupted, restore the entire previous set before another launch."""
    journal=base/'.update-journal.json';backup=base/'.update-backup'
    if not journal.exists():return
    state=json.loads(journal.read_text())
    for name,existed in state.items():
        if name not in ALLOWED:raise ValueError('Invalid recovery journal')
        path=base/name
        if existed:
            temp=base/(name+'.recovering');shutil.copyfile(backup/name,temp);os.replace(temp,path)
        else:path.unlink(missing_ok=True)
    journal.unlink();shutil.rmtree(backup,ignore_errors=True)

def install(files,base=BASE):
    recover(base);backup=base/'.update-backup';shutil.rmtree(backup,ignore_errors=True);backup.mkdir()
    state={name:(base/name).exists() for name in files}
    for name,existed in state.items():
        if existed:shutil.copyfile(base/name,backup/name)
    journal=base/'.update-journal.json';temp_journal=base/'.update-journal.tmp';temp_journal.write_text(json.dumps(state));os.replace(temp_journal,journal)
    try:
        # Version last; commit by removing journal only when every file succeeded.
        for name in sorted(files,key=lambda n:n=='VERSION'):
            temp=base/(name+'.installing');temp.write_bytes(files[name]);os.replace(temp,base/name)
        journal.unlink()
    except BaseException:
        recover(base);raise
    shutil.rmtree(backup,ignore_errors=True)

def check_and_install(base=BASE, config=None):
    recover(base);config=settings() if config is None else config
    if not config.get('automatic',True):return 'Автомат шалгалт унтраалттай.'
    url=config.get('manifest_url','').strip()
    if not url:return 'Update нийтлэх хаяг тохируулаагүй. Одоогийн хувилбар ажиллана.'
    manifest=json.loads(fetch(url,64*1024))
    if manifest.get('protocol')!=1:raise ValueError('Unsupported update protocol')
    remote=manifest['version']
    if version(remote)<=version(local_version(base)):return 'Шинэ хувилбар байхгүй.'
    expected=manifest['sha256']
    if not re.fullmatch('[0-9a-fA-F]{64}',expected):raise ValueError('Missing SHA-256 digest')
    blob=fetch(manifest['url'],MAX_ZIP)
    if hashlib.sha256(blob).hexdigest()!=expected.lower():raise ValueError('SHA-256 mismatch: update rejected')
    files=unpack_package(blob,remote)
    if files['requirements.txt']!=(base/'requirements.txt').read_bytes():
        raise ValueError('Dependencies changed; install this version manually. Existing version retained.')
    install(files,base)
    return 'Шинэчилсэн: '+remote
