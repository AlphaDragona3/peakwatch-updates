"""Check for updates BEFORE starting the app. Never replace a running monitor."""
import subprocess,sys
from pathlib import Path
BASE=Path(__file__).resolve().parent
from updater import DATA,check_and_install,recover
# Hold a per-user launch lock while the monitor runs, including during update.
DATA.mkdir(parents=True,exist_ok=True)
lock_file=(DATA/'launcher.lock').open('a+b')
if sys.platform=='win32':
    import msvcrt
    lock_file.seek(0,2)
    if lock_file.tell()==0:lock_file.write(b'0');lock_file.flush()
    lock_file.seek(0)
    try:msvcrt.locking(lock_file.fileno(),msvcrt.LK_NBLCK,1)
    except OSError:raise SystemExit('PeakWatch is already running for this user. Close it first.')
try:
    recover()
except Exception as exc:
    raise SystemExit('Update recovery failed; app not started: '+str(exc))
try:status=check_and_install()
except Exception as exc:status='Update шалгаж чадсангүй; өмнөх хувилбар ажиллана. '+str(exc)
DATA.mkdir(parents=True,exist_ok=True)
(DATA/'update_status.txt').write_text(status,encoding='utf-8')
print(status)
raise SystemExit(subprocess.call([sys.executable,str(BASE/'peakwatch.py')],cwd=BASE))
