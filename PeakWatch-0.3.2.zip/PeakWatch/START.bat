@echo off
cd /d "%~dp0"
if not exist ".venv\Scripts\python.exe" (
  py -3.11 -m venv .venv
  if errorlevel 1 (
    echo Install Python 3.11 64-bit from python.org, including the Python launcher.
    pause
    exit /b 1
  )
)
.venv\Scripts\python.exe -c "import rapidocr_onnxruntime, mss, PIL, numpy" >nul 2>&1
if errorlevel 1 (
  .venv\Scripts\python.exe -m pip install -r requirements.txt
  if errorlevel 1 (
    echo Dependency installation failed. Check Internet access.
    pause
    exit /b 1
  )
)
.venv\Scripts\python.exe launcher.py
if errorlevel 1 pause
