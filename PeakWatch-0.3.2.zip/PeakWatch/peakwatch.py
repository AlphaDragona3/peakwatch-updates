"""Windows OCR status monitor for GeneMapper Samples Plot; explicit opt-in."""
import sys, os, json, threading, queue, time
from pathlib import Path
import tkinter as tk
from tkinter import ttk, messagebox, simpledialog, filedialog
from core import parse_status, review, validate_rule
from panels import read_panels, read_bins, overlaps
BASE=Path(__file__).resolve().parent
from updater import DATA, settings, write_settings, https_url
DATA.mkdir(parents=True,exist_ok=True)
CONFIG=DATA/'profiles.json'
if not CONFIG.exists() and (BASE/'profiles.json').exists():
    import shutil
    shutil.copyfile(BASE/'profiles.json',CONFIG)

class App:
    def __init__(self):
        self.root=tk.Tk();self.root.title('PeakWatch 0.3.2 — GeneMapper 6.1 туршилт')
        self.root.geometry('650x860');self.root.attributes('-topmost',True)
        self.stop=threading.Event();self.running=False;self.events=queue.Queue();self.worker=None
        try:self.profiles=json.loads(CONFIG.read_text(encoding='utf-8')) if CONFIG.exists() else {}
        except Exception:self.profiles={}
        self.marker='';self.rule={};self.beep=True
        self.data_warning=tk.StringVar(value='')
        box=ttk.Frame(self.root,padding=14);box.pack(fill='both',expand=True)
        ttk.Label(box,text='PeakWatch · Туршилтын хувилбар',font=('Segoe UI',16,'bold')).pack(anchor='w')
        ttk.Label(box,text='Хулганын доорх peak-ийг уншина. Аллель автоматаар сонгохгүй.',wraplength=520).pack(anchor='w',pady=(4,12))
        row=ttk.Frame(box);row.pack(fill='x')
        self.btn=ttk.Button(row,text='Хяналт эхлүүлэх',command=self.toggle);self.btn.pack(side='left')
        self.sound=tk.BooleanVar(value=True)
        ttk.Checkbutton(row,text='Дуу',variable=self.sound,command=lambda:setattr(self,'beep',self.sound.get())).pack(side='left',padx=10)
        self.state=tk.StringVar(value='Зогссон. Дэлгэц уншихын өмнө эхлүүлнэ.')
        ttk.Label(box,textvariable=self.state,wraplength=520).pack(anchor='w',pady=10)
        panel_row=ttk.Frame(box);panel_row.pack(fill='x',pady=4)
        ttk.Button(panel_row,text='Panel файл оруулах',command=self.import_panel).pack(side='left')
        ttk.Button(panel_row,text='Bin файл оруулах',command=self.import_bin).pack(side='left',padx=4)
        ttk.Button(panel_row,text='Маркерийн хүснэгт',command=self.marker_table).pack(side='left')
        ttk.Label(box,textvariable=self.data_warning,wraplength=600).pack(anchor='w')
        frm=ttk.LabelFrame(box,text='Маркер ба лабораторийн баталгаажсан босго',padding=8);frm.pack(fill='x')
        self.vars={k:tk.StringVar() for k in ['marker','min_bp','max_bp','min_rfu','max_rfu']}
        for i,(key,label) in enumerate([('marker','Маркер (гараар баталгаажуулна)'),('min_bp','Min bp'),('max_bp','Max bp'),('min_rfu','Min RFU'),('max_rfu','Max RFU')]):
            ttk.Label(frm,text=label).grid(row=i,column=0,sticky='w',pady=3)
            widget=ttk.Combobox(frm,textvariable=self.vars[key],values=list(self.profiles)) if key=='marker' else ttk.Entry(frm,textvariable=self.vars[key])
            widget.grid(row=i,column=1,sticky='ew',padx=8)
            if key=='marker':
                self.marker_combo=widget
                widget.bind('<<ComboboxSelected>>',self.load_rule)
                widget.bind('<KeyRelease>',self.invalidate_rule)
        frm.columnconfigure(1,weight=1)
        ttk.Button(frm,text='Босгыг баталгаажуулж хадгалах',command=self.save_rule).grid(row=5,column=0,columnspan=2,pady=8)
        ttk.Label(frm,text='Хоосон босгыг шалгахгүй. Маркер солих бүрд нэрээ шинэчилнэ.',wraplength=490).grid(row=6,column=0,columnspan=2,sticky='w')
        self.metadata=tk.StringVar(value='Panel: гараар оруулсан тохиргоо')
        ttk.Label(box,textvariable=self.metadata,wraplength=600).pack(anchor='w',pady=4)
        self.peak=tk.StringVar(value='Уншсан peak: —')
        ttk.Label(box,textvariable=self.peak,font=('Segoe UI',12,'bold'),wraplength=520).pack(anchor='w',pady=12)
        self.result=tk.Label(box,text='Уншилт хүлээж байна.',justify='left',anchor='w',wraplength=510,bg='#edf2f7',padx=10,pady=10)
        self.result.pack(fill='x')
        self.raw=tk.StringVar(value='OCR: —')
        ttk.Label(box,textvariable=self.raw,wraplength=520).pack(anchor='w',pady=10)
        ttk.Label(box,text='0.3: зөвхөн status мөрийн bp/RFU, allele ? шалгана.\nStutter, +A/−A, pull-up, hetero/homo ангилал хийгдээгүй.',wraplength=520).pack(anchor='w')
        ttk.Button(box,text='Автомат update тохируулах',command=self.update_options).pack(anchor='w',pady=5)
        try: update_status=(DATA/'update_status.txt').read_text(encoding='utf-8')
        except OSError: update_status='Update нийтлэх хаяг тохируулаагүй.'
        ttk.Label(box,text=update_status,wraplength=520).pack(anchor='w')
        self.root.protocol('WM_DELETE_WINDOW',self.close);self.root.after(100,self.poll)

    def update_options(self):
        config=settings()
        url=simpledialog.askstring('Update эх үүсвэр','Өөрийн итгэдэг release manifest.json-ийн HTTPS хаяг.\nХоосон үлдээвэл шинэчлэл шалгахгүй.',initialvalue=config.get('manifest_url',''),parent=self.root)
        if url is None:return
        try:
            if url.strip():https_url(url.strip())
            write_settings({'manifest_url':url.strip(),'automatic':bool(url.strip())})
            messagebox.showinfo('Update','Хадгаллаа. Дараагийн START.bat нээлтээр шалгана.\nХяналт явагдаж байхад шинэчлэл суулгахгүй.')
        except Exception as exc:messagebox.showerror('Update',str(exc))

    def load_rule(self,event=None):
        rule=self.profiles.get(self.vars['marker'].get(),{})
        for k in ('min_bp','max_bp','min_rfu','max_rfu'):self.vars[k].set('' if rule.get(k) is None else str(rule[k]))
        self.marker=rule.get('marker_name',self.vars['marker'].get());self.rule=dict(rule)
        self.show_metadata(rule)

    def save_rule(self):
        try:
            marker=self.vars['marker'].get().strip()
            if not marker:raise ValueError('Маркерийн нэр оруулна уу.')
            rule=dict(self.profiles.get(marker,{}))
            rule.update({k:float(self.vars[k].get()) if self.vars[k].get().strip() else None for k in ('min_bp','max_bp','min_rfu','max_rfu')})
            validate_rule(rule)
            self.profiles[marker]=rule
            tmp=CONFIG.with_suffix('.tmp');tmp.write_text(json.dumps(self.profiles,ensure_ascii=False,indent=2),encoding='utf-8');tmp.replace(CONFIG)
            self.marker=rule.get('marker_name',marker);self.rule=rule
            self.refresh_markers();self.show_metadata(rule)
            self.state.set('Хадгалсан: '+marker+' (маркер гараар баталгаажсан).')
        except Exception as exc:messagebox.showerror('Тохиргоо',str(exc))

    def persist_profiles(self,profiles):
        tmp=CONFIG.with_suffix('.tmp');tmp.write_text(json.dumps(profiles,ensure_ascii=False,indent=2),encoding='utf-8');tmp.replace(CONFIG)
        self.profiles=profiles;self.refresh_markers()

    def refresh_markers(self):
        self.marker_combo.configure(values=sorted(self.profiles))

    def invalidate_rule(self,event=None):
        self.marker='';self.rule={}
        self.metadata.set('Нэр өөрчлөгдсөн: жагсаалтаас сонгох эсвэл хадгалж баталгаажуулна уу.')

    def show_metadata(self,rule):
        self.metadata.set(' | '.join(str(x) for x in [rule.get('kit','Manual'),rule.get('panel',''),rule.get('dye',''),
            'Repeat(raw): '+str(rule.get('repeat_type_raw','—')), ('Bins: '+str(len(rule['bins'])) if rule.get('bins') else 'Bins: байхгүй — bin шалгахгүй'),
            'Source: '+rule.get('source_file','гараар')] if x))

    def import_panel(self):
        path=filedialog.askopenfilename(parent=self.root,title='GeneMapper Panel TXT эсвэл CSV/TSV',filetypes=[('Panel text','*.txt *.tsv *.csv'),('All','*.*')])
        if not path:return
        try:
            incoming=read_panels(path)
            duplicate=set(incoming)&set(self.profiles)
            fresh={k:v for k,v in incoming.items() if k not in duplicate}
            preview='\n'.join(f"{k}: {r['dye']} {r['min_bp']:g}–{r['max_bp']:g} bp" for k,r in list(fresh.items())[:12])
            if not fresh:
                messagebox.showinfo('Panel','Бүх маркер өмнө нь орсон байна. Хуучин тохиргоог дарж бичээгүй.');return
            if not messagebox.askyesno('Panel шалгаж оруулах',f'{len(fresh)} шинэ маркер. {len(duplicate)} давхардлыг алгасана.\n\n{preview}\n\nЭдгээрийг оруулах уу?',parent=self.root):return
            updated=dict(self.profiles);updated.update(fresh);self.persist_profiles(updated)
            first=next(iter(fresh));self.vars['marker'].set(first);self.load_rule()
            warnings=overlaps({k:v for k,v in updated.items() if v.get('marker_name')})
            self.data_warning.set(f'Panel: {len(fresh)} маркер орлоо. RFU босгыг тусад нь оруулна. Давхцал: {len(warnings)}.')
            if warnings:messagebox.showwarning('Ижил өнгийн хүрээ давхцсан','\n'.join(warnings[:20]))
        except Exception as exc:messagebox.showerror('Panel импорт',str(exc))

    def import_bin(self):
        path=filedialog.askopenfilename(parent=self.root,title='GeneMapper Bin TXT',filetypes=[('Bin text','*.txt *.tsv'),('All','*.*')])
        if not path:return
        try:
            incoming=read_bins(path);missing=set(incoming)-set(self.profiles)
            if missing:raise ValueError('Таарах Panel/Kit/Marker олдсонгүй. Импорт хийгдээгүй:\n'+'\n'.join(sorted(missing)[:10]))
            if not messagebox.askyesno('Bin шалгах',f'{len(incoming)} маркерийн BinSet-ийг холбох уу?\nЭдгээр маркерийн хуучин bins солигдоно.',parent=self.root):return
            updated={k:dict(v) for k,v in self.profiles.items()}
            for k,v in incoming.items():updated[k].update(v);updated[k]['bin_source_file']=Path(path).name
            self.persist_profiles(updated);self.load_rule()
            empty=sum(not v['bins'] for v in incoming.values())
            self.data_warning.set(f'Bin: {len(incoming)-empty} маркерт bin байна; {empty} маркер хоосон. Хоосон маркерт bin шалгалт хийхгүй.')
        except Exception as exc:messagebox.showerror('Bin импорт',str(exc))

    def marker_table(self):
        win=tk.Toplevel(self.root);win.title('Маркерийн мэдээлэл');win.geometry('1050x500')
        columns=('kit','panel','marker_name','dye','min_bp','max_bp','repeat_type_raw','stutter_ratio_raw','bins')
        tree=ttk.Treeview(win,columns=columns,show='headings',selectmode='browse')
        for c in columns:tree.heading(c,text=c);tree.column(c,width=105,stretch=True)
        scroll=ttk.Scrollbar(win,orient='vertical',command=tree.yview);tree.configure(yscrollcommand=scroll.set)
        scroll.pack(side='right',fill='y');tree.pack(fill='both',expand=True)
        mapping={}
        for k,r in self.profiles.items():
            values=[len(r.get('bins',[])) if c=='bins' else r.get(c,k if c=='marker_name' else '') for c in columns]
            mapping[tree.insert('', 'end',values=values)]=k
        def select():
            chosen=tree.selection()
            if chosen:self.vars['marker'].set(mapping[chosen[0]]);self.load_rule();win.destroy()
        ttk.Button(win,text='Маркер сонгох / bp, RFU засах',command=select).pack(pady=4)
        ttk.Label(win,text='Kit/Panel/өнгө/Repeat нь эх файлаас. Засахдаа Panel-аа GeneMapper-т экспортлоод шинэ нэртэйгээр оруулна.').pack(pady=4)

    def toggle(self):
        if self.running:
            self.running=False;self.stop.set();self.btn.config(state='disabled',text='Зогсоож байна…');return
        if self.worker and self.worker.is_alive():return
        self.stop.clear();self.running=True;self.btn.config(text='Хяналт зогсоох')
        self.worker=threading.Thread(target=self.monitor,daemon=True);self.worker.start()

    def send(self,*data):self.events.put(data)

    def monitor(self):
        try:
            import ctypes
            from ctypes import wintypes as wt
            import numpy as np
            import mss
            from PIL import Image
            from rapidocr_onnxruntime import RapidOCR
            u=ctypes.windll.user32
            u.GetForegroundWindow.restype=wt.HWND
            u.GetWindowTextW.argtypes=[wt.HWND,wt.LPWSTR,ctypes.c_int]
            u.GetClientRect.argtypes=[wt.HWND,ctypes.POINTER(wt.RECT)]
            u.ClientToScreen.argtypes=[wt.HWND,ctypes.POINTER(wt.POINT)]
            u.IsIconic.argtypes=[wt.HWND]
            self.send('state','OCR хөдөлгүүр ачаалж байна…')
            engine=RapidOCR(intra_op_num_threads=1, inter_op_num_threads=1, det_limit_type='max', det_limit_side_len=2000)
            previous=None;last_notice=None;last_mouse=None
            with mss.mss() as screen:
                while not self.stop.wait(.7):
                    h=u.GetForegroundWindow();buf=ctypes.create_unicode_buffer(512);u.GetWindowTextW(h,buf,512)
                    if buf.value.strip()!='Samples Plot' or u.IsIconic(h):
                        previous=None;self.send('empty','GeneMapper-ийн Samples Plot-ийг идэвхтэй болгоно уу.');continue
                    rect=wt.RECT();origin=wt.POINT(0,0);mouse=wt.POINT()
                    if not u.GetClientRect(h,ctypes.byref(rect)) or not u.ClientToScreen(h,ctypes.byref(origin)):
                        previous=None;self.send('empty','Цонхны байршил олдсонгүй.');continue
                    u.GetCursorPos(ctypes.byref(mouse))
                    if not (origin.x<=mouse.x<origin.x+rect.right and origin.y+100<=mouse.y<origin.y+rect.bottom-40):
                        previous=None;self.send('empty','Хулганаа графикийн peak дээр байрлуулна уу.');continue
                    pos=(mouse.x,mouse.y)
                    if pos!=last_mouse:
                        last_mouse=pos;previous=None;self.send('empty','Хулганаа peak дээр түр тогтооно уу.');continue
                    region={'left':origin.x,'top':origin.y+rect.bottom-32,'width':min(1000,rect.right),'height':32}
                    if region['width']<200:continue
                    shot=screen.grab(region);im=Image.frombytes('RGB',shot.size,shot.rgb)
                    im=im.resize((im.width*2,im.height*2))
                    lines,_=engine(np.array(im))
                    lines=sorted(lines or [],key=lambda row:row[0][0][0])
                    text=' '.join(row[1] for row in lines)
                    peak=parse_status(text)
                    if not peak or not lines or min(float(row[2]) for row in lines)<.92:
                        previous=None;self.send('empty','Уншилт баталгаажаагүй. Дүгнэлт өгөөгүй.',text);continue
                    if peak!=previous:
                        previous=peak;self.send('empty','Уншилтыг давтан баталгаажуулж байна…',text);continue
                    # A repeated OCR result is not proof of correctness; always show raw text.
                    self.send('peak',peak,text)
                    key=(peak,self.marker,tuple(self.rule.items()))
                    notes=review(peak,self.marker,self.rule)
                    if any(n.startswith('Сэжигтэй:') for n in notes) and key!=last_notice:
                        last_notice=key
                        if self.beep:
                            import winsound
                            winsound.MessageBeep(winsound.MB_ICONEXCLAMATION)
        except Exception as exc:self.send('error',str(exc))
        finally:self.send('ended')

    def poll(self):
        try:
            while True:
                item=self.events.get_nowait();kind=item[0]
                if kind=='peak' and self.running:
                    peak,text=item[1:];notes=review(peak,self.marker,self.rule)
                    self.state.set('Хулганын доорх peak · OCR · сонгосон аллель гэдгийг батлахгүй')
                    self.peak.set(f'{peak.size:g} bp  ·  {peak.height:g} RFU  ·  Point {peak.point}')
                    self.raw.set('OCR: '+text)
                    self.result.config(text='\n'.join(notes),bg='#fff0cb' if any(n.startswith('Сэжигтэй:') for n in notes) else '#edf2f7')
                elif kind in ('empty','error','state'):
                    self.state.set(item[1]);self.peak.set('Уншсан peak: —');self.result.config(text='Дүгнэлт өгөөгүй.',bg='#edf2f7');self.raw.set('OCR: '+(item[2] if len(item)>2 else '—'))
                elif kind=='ended':
                    self.running=False;self.btn.config(state='normal',text='Хяналт эхлүүлэх');self.peak.set('Уншсан peak: —');self.state.set('Зогссон.');self.result.config(text='Дүгнэлт өгөөгүй.',bg='#edf2f7')
        except queue.Empty:pass
        self.root.after(100,self.poll)

    def close(self):self.stop.set();self.root.destroy()

if __name__=='__main__':
    if sys.platform!='win32':raise SystemExit('Windows 10/11 шаардлагатай. core.py шалгалтыг өөр системд ажиллуулж болно.')
    import ctypes
    try:ctypes.windll.user32.SetProcessDpiAwarenessContext(ctypes.c_void_p(-4))
    except Exception:pass
    App().root.mainloop()
