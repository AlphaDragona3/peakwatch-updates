"""Windows OCR status monitor for GeneMapper Samples Plot; explicit opt-in."""
import sys, os, json, threading, queue, time
from pathlib import Path
import tkinter as tk
from tkinter import ttk, messagebox, simpledialog, filedialog
from core import parse_status, review, validate_rule, detect_panel, resolve_marker
from panels import read_panels, read_bins, overlaps
BASE=Path(__file__).resolve().parent
from updater import DATA, settings, write_settings, https_url
DATA.mkdir(parents=True,exist_ok=True)
CONFIG=DATA/'profiles.json'
if not CONFIG.exists() and (BASE/'profiles.json').exists():
    import shutil
    shutil.copyfile(BASE/'profiles.json',CONFIG)

class App:
    def __init__(self):
        self.root=tk.Tk();self.root.title('PeakWatch 0.4.0 — GeneMapper 6.1 туршилт')
        self.root.geometry('650x860');self.root.attributes('-topmost',True)
        self.stop=threading.Event();self.running=False;self.events=queue.Queue();self.worker=None
        try:self.profiles=json.loads(CONFIG.read_text(encoding='utf-8')) if CONFIG.exists() else {}
        except Exception:self.profiles={}
        self.marker='';self.rule={};self.beep=True
        self.data_warning=tk.StringVar(value='')
        box=ttk.Frame(self.root,padding=14);box.pack(fill='both',expand=True)
        ttk.Label(box,text='PeakWatch · Туршилтын хувилбар',font=('Segoe UI',16,'bold')).pack(anchor='w')
        ttk.Label(box,text='Хулганын доорх peak-ийг уншина. Аллель автоматаар сонгохгүй.',wraplength=520).pack(anchor='w',pady=(4,12))
        row=ttk.Frame(box);row.pack(fill='x')
        self.btn=ttk.Button(row,text='Хяналт эхлүүлэх',command=self.toggle);self.btn.pack(side='left')
        self.sound=tk.BooleanVar(value=True)
        ttk.Checkbutton(row,text='Дуу',variable=self.sound,command=lambda:setattr(self,'beep',self.sound.get())).pack(side='left',padx=10)
        self.state=tk.StringVar(value='Зогссон. Дэлгэц уншихын өмнө эхлүүлнэ.')
        ttk.Label(box,textvariable=self.state,wraplength=520).pack(anchor='w',pady=10)
        ttk.Button(box,text='Файлаас шинжлэх / автомат хавтас',command=lambda:FileAnalysis(self)).pack(anchor='w',pady=4)
        panel_row=ttk.Frame(box);panel_row.pack(fill='x',pady=4)
        ttk.Button(panel_row,text='Panel файл оруулах',command=self.import_panel).pack(side='left')
        ttk.Button(panel_row,text='Bin файл оруулах',command=self.import_bin).pack(side='left',padx=4)
        ttk.Button(panel_row,text='Маркерийн хүснэгт',command=self.marker_table).pack(side='left')
        ttk.Label(box,textvariable=self.data_warning,wraplength=600).pack(anchor='w')
        frm=ttk.LabelFrame(box,text='Маркер ба лабораторийн баталгаажсан босго',padding=8);frm.pack(fill='x')
        self.vars={k:tk.StringVar() for k in ['marker','min_bp','max_bp','min_rfu','max_rfu']}
        for i,(key,label) in enumerate([('marker','Маркер (автоматаар сонгоно)'),('min_bp','Min bp'),('max_bp','Max bp'),('min_rfu','Min RFU'),('max_rfu','Max RFU')]):
            ttk.Label(frm,text=label).grid(row=i,column=0,sticky='w',pady=3)
            widget=ttk.Combobox(frm,textvariable=self.vars[key],values=list(self.profiles)) if key=='marker' else ttk.Entry(frm,textvariable=self.vars[key])
            widget.grid(row=i,column=1,sticky='ew',padx=8)
            if key=='marker':
                self.marker_combo=widget
                widget.bind('<<ComboboxSelected>>',self.load_rule)
                widget.bind('<KeyRelease>',self.invalidate_rule)
        frm.columnconfigure(1,weight=1)
        ttk.Button(frm,text='Босгыг баталгаажуулж хадгалах',command=self.save_rule).grid(row=5,column=0,columnspan=2,pady=8)
        ttk.Label(frm,text='Хоосон босгыг шалгахгүй. Panel ба маркерийг уншилтаас автоматаар сонгоно.',wraplength=490).grid(row=6,column=0,columnspan=2,sticky='w')
        self.metadata=tk.StringVar(value='Panel: гараар оруулсан тохиргоо')
        ttk.Label(box,textvariable=self.metadata,wraplength=600).pack(anchor='w',pady=4)
        self.peak=tk.StringVar(value='Уншсан peak: —')
        ttk.Label(box,textvariable=self.peak,font=('Segoe UI',12,'bold'),wraplength=520).pack(anchor='w',pady=12)
        self.result=tk.Label(box,text='Уншилт хүлээж байна.',justify='left',anchor='w',wraplength=510,bg='#edf2f7',padx=10,pady=10)
        self.result.pack(fill='x')
        self.raw=tk.StringVar(value='OCR: —')
        ttk.Label(box,textvariable=self.raw,wraplength=520).pack(anchor='w',pady=10)
        ttk.Label(box,text='OCR горим: зөвхөн status мөр.\nHetero/homo санал, артефакт харьцуулалт: Файлаас шинжлэх цонхонд.',wraplength=520).pack(anchor='w')
        ttk.Button(box,text='Автомат update тохируулах',command=self.update_options).pack(anchor='w',pady=5)
        try: update_status=(DATA/'update_status.txt').read_text(encoding='utf-8')
        except OSError: update_status='Update нийтлэх хаяг тохируулаагүй.'
        ttk.Label(box,text=update_status,wraplength=520).pack(anchor='w')
        self.root.protocol('WM_DELETE_WINDOW',self.close);self.root.after(100,self.poll)

    def update_options(self):
        config=settings()
        url=simpledialog.askstring('Update эх үүсвэр','Өөрийн итгэдэг release manifest.json-ийн HTTPS хаяг.\nХоосон үлдээвэл шинэчлэл шалгахгүй.',initialvalue=config.get('manifest_url',''),parent=self.root)
        if url is None:return
        try:
            if url.strip():https_url(url.strip())
            write_settings({'manifest_url':url.strip(),'automatic':bool(url.strip())})
            messagebox.showinfo('Update','Хадгаллаа. Дараагийн START.bat нээлтээр шалгана.\nХяналт явагдаж байхад шинэчлэл суулгахгүй.')
        except Exception as exc:messagebox.showerror('Update',str(exc))

    def load_rule(self,event=None):
        rule=self.profiles.get(self.vars['marker'].get(),{})
        for k in ('min_bp','max_bp','min_rfu','max_rfu'):self.vars[k].set('' if rule.get(k) is None else str(rule[k]))
        self.marker=rule.get('marker_name',self.vars['marker'].get());self.rule=dict(rule)
        self.show_metadata(rule)

    def save_rule(self):
        try:
            marker=self.vars['marker'].get().strip()
            if not marker:raise ValueError('Маркерийн нэр оруулна уу.')
            rule=dict(self.profiles.get(marker,{}))
            rule.update({k:float(self.vars[k].get()) if self.vars[k].get().strip() else None for k in ('min_bp','max_bp','min_rfu','max_rfu')})
            validate_rule(rule)
            self.profiles[marker]=rule
            tmp=CONFIG.with_suffix('.tmp');tmp.write_text(json.dumps(self.profiles,ensure_ascii=False,indent=2),encoding='utf-8');tmp.replace(CONFIG)
            self.marker=rule.get('marker_name',marker);self.rule=rule
            self.refresh_markers();self.show_metadata(rule)
            self.state.set('Хадгалсан: '+marker+' (маркер гараар баталгаажсан).')
        except Exception as exc:messagebox.showerror('Тохиргоо',str(exc))

    def persist_profiles(self,profiles):
        tmp=CONFIG.with_suffix('.tmp');tmp.write_text(json.dumps(profiles,ensure_ascii=False,indent=2),encoding='utf-8');tmp.replace(CONFIG)
        self.profiles=profiles;self.refresh_markers()

    def refresh_markers(self):
        self.marker_combo.configure(values=sorted(self.profiles))

    def invalidate_rule(self,event=None):
        self.marker='';self.rule={}
        self.metadata.set('Нэр өөрчлөгдсөн: жагсаалтаас сонгох эсвэл хадгалж баталгаажуулна уу.')

    def show_metadata(self,rule):
        self.metadata.set(' | '.join(str(x) for x in [rule.get('kit','Manual'),rule.get('panel',''),rule.get('dye',''),
            'Repeat(raw): '+str(rule.get('repeat_type_raw','—')), ('Bins: '+str(len(rule['bins'])) if rule.get('bins') else 'Bins: байхгүй — bin шалгахгүй'),
            'Source: '+rule.get('source_file','гараар')] if x))

    def import_panel(self):
        path=filedialog.askopenfilename(parent=self.root,title='GeneMapper Panel TXT эсвэл CSV/TSV',filetypes=[('Panel text','*.txt *.tsv *.csv'),('All','*.*')])
        if not path:return
        try:
            incoming=read_panels(path)
            duplicate=set(incoming)&set(self.profiles)
            fresh={k:v for k,v in incoming.items() if k not in duplicate}
            preview='\n'.join(f"{k}: {r['dye']} {r['min_bp']:g}–{r['max_bp']:g} bp" for k,r in list(fresh.items())[:12])
            if not fresh:
                messagebox.showinfo('Panel','Бүх маркер өмнө нь орсон байна. Хуучин тохиргоог дарж бичээгүй.');return
            if not messagebox.askyesno('Panel шалгаж оруулах',f'{len(fresh)} шинэ маркер. {len(duplicate)} давхардлыг алгасана.\n\n{preview}\n\nЭдгээрийг оруулах уу?',parent=self.root):return
            updated=dict(self.profiles);updated.update(fresh);self.persist_profiles(updated)
            first=next(iter(fresh));self.vars['marker'].set(first);self.load_rule()
            warnings=overlaps({k:v for k,v in updated.items() if v.get('marker_name')})
            self.data_warning.set(f'Panel: {len(fresh)} маркер орлоо. RFU босгыг тусад нь оруулна. Давхцал: {len(warnings)}.')
            if warnings:messagebox.showwarning('Ижил өнгийн хүрээ давхцсан','\n'.join(warnings[:20]))
        except Exception as exc:messagebox.showerror('Panel импорт',str(exc))

    def import_bin(self):
        path=filedialog.askopenfilename(parent=self.root,title='GeneMapper Bin TXT',filetypes=[('Bin text','*.txt *.tsv'),('All','*.*')])
        if not path:return
        try:
            incoming=read_bins(path);missing=set(incoming)-set(self.profiles)
            if missing:raise ValueError('Таарах Panel/Kit/Marker олдсонгүй. Импорт хийгдээгүй:\n'+'\n'.join(sorted(missing)[:10]))
            if not messagebox.askyesno('Bin шалгах',f'{len(incoming)} маркерийн BinSet-ийг холбох уу?\nЭдгээр маркерийн хуучин bins солигдоно.',parent=self.root):return
            updated={k:dict(v) for k,v in self.profiles.items()}
            for k,v in incoming.items():updated[k].update(v);updated[k]['bin_source_file']=Path(path).name
            self.persist_profiles(updated);self.load_rule()
            empty=sum(not v['bins'] for v in incoming.values())
            self.data_warning.set(f'Bin: {len(incoming)-empty} маркерт bin байна; {empty} маркер хоосон. Хоосон маркерт bin шалгалт хийхгүй.')
        except Exception as exc:messagebox.showerror('Bin импорт',str(exc))

    def marker_table(self):
        win=tk.Toplevel(self.root);win.title('Маркерийн мэдээлэл');win.geometry('1050x500')
        columns=('kit','panel','marker_name','dye','min_bp','max_bp','repeat_type_raw','stutter_ratio_raw','bins')
        tree=ttk.Treeview(win,columns=columns,show='headings',selectmode='browse')
        for c in columns:tree.heading(c,text=c);tree.column(c,width=105,stretch=True)
        scroll=ttk.Scrollbar(win,orient='vertical',command=tree.yview);tree.configure(yscrollcommand=scroll.set)
        scroll.pack(side='right',fill='y');tree.pack(fill='both',expand=True)
        mapping={}
        for k,r in self.profiles.items():
            values=[len(r.get('bins',[])) if c=='bins' else r.get(c,k if c=='marker_name' else '') for c in columns]
            mapping[tree.insert('', 'end',values=values)]=k
        def select():
            chosen=tree.selection()
            if chosen:self.vars['marker'].set(mapping[chosen[0]]);self.load_rule();win.destroy()
        ttk.Button(win,text='Маркер сонгох / bp, RFU засах',command=select).pack(pady=4)
        ttk.Label(win,text='Kit/Panel/өнгө/Repeat нь эх файлаас. Засахдаа Panel-аа GeneMapper-т экспортлоод шинэ нэртэйгээр оруулна.').pack(pady=4)

    def toggle(self):
        if self.running:
            self.running=False;self.stop.set();self.btn.config(state='disabled',text='Зогсоож байна…');return
        if self.worker and self.worker.is_alive():return
        self.stop.clear();self.running=True;self.btn.config(text='Хяналт зогсоох')
        self.worker=threading.Thread(target=self.monitor,daemon=True);self.worker.start()

    def send(self,*data):self.events.put(data)

    def monitor(self):
        try:
            import ctypes
            from ctypes import wintypes as wt
            import numpy as np
            import mss
            from PIL import Image
            from rapidocr_onnxruntime import RapidOCR
            u=ctypes.windll.user32
            u.GetForegroundWindow.restype=wt.HWND
            u.GetWindowTextW.argtypes=[wt.HWND,wt.LPWSTR,ctypes.c_int]
            u.GetClientRect.argtypes=[wt.HWND,ctypes.POINTER(wt.RECT)]
            u.ClientToScreen.argtypes=[wt.HWND,ctypes.POINTER(wt.POINT)]
            u.IsIconic.argtypes=[wt.HWND]
            self.send('state','OCR хөдөлгүүр ачаалж байна…')
            engine=RapidOCR(intra_op_num_threads=1, inter_op_num_threads=1, det_limit_type='max', det_limit_side_len=2000)
            previous=None;last_notice=None;last_mouse=None
            with mss.mss() as screen:
                while not self.stop.wait(.7):
                    h=u.GetForegroundWindow();buf=ctypes.create_unicode_buffer(512);u.GetWindowTextW(h,buf,512)
                    if buf.value.strip()!='Samples Plot' or u.IsIconic(h):
                        previous=None;self.send('empty','GeneMapper-ийн Samples Plot-ийг идэвхтэй болгоно уу.');continue
                    rect=wt.RECT();origin=wt.POINT(0,0);mouse=wt.POINT()
                    if not u.GetClientRect(h,ctypes.byref(rect)) or not u.ClientToScreen(h,ctypes.byref(origin)):
                        previous=None;self.send('empty','Цонхны байршил олдсонгүй.');continue
                    u.GetCursorPos(ctypes.byref(mouse))
                    if not (origin.x<=mouse.x<origin.x+rect.right and origin.y+100<=mouse.y<origin.y+rect.bottom-40):
                        previous=None;self.send('empty','Хулганаа графикийн peak дээр байрлуулна уу.');continue
                    pos=(mouse.x,mouse.y)
                    if pos!=last_mouse:
                        last_mouse=pos;previous=None;self.send('empty','Хулганаа peak дээр түр тогтооно уу.');continue
                    region={'left':origin.x,'top':origin.y+rect.bottom-32,'width':min(1000,rect.right),'height':32}
                    if region['width']<200:continue
                    shot=screen.grab(region);im=Image.frombytes('RGB',shot.size,shot.rgb)
                    im=im.resize((im.width*2,im.height*2))
                    lines,_=engine(np.array(im))
                    lines=sorted(lines or [],key=lambda row:row[0][0][0])
                    text=' '.join(row[1] for row in lines)
                    header_region={'left':origin.x,'top':origin.y+80,'width':min(1000,rect.right),'height':75}
                    header_shot=screen.grab(header_region)
                    header_im=Image.frombytes('RGB',header_shot.size,header_shot.rgb)
                    header_lines,_=engine(np.array(header_im.resize((header_im.width*2,header_im.height*2))))
                    header_text=' '.join(row[1] for row in (header_lines or []) if float(row[2])>=.92)
                    panel=detect_panel(header_text,self.profiles)
                    peak=parse_status(text)
                    if not peak or not lines or min(float(row[2]) for row in lines)<.92:
                        previous=None;self.send('empty','Уншилт баталгаажаагүй. Дүгнэлт өгөөгүй.',text);continue
                    if (peak,panel)!=previous:
                        previous=(peak,panel);self.send('empty','Уншилтыг давтан баталгаажуулж байна…',text);continue
                    # A repeated OCR result is not proof of correctness; always show raw text.
                    self.send('peak',peak,text,panel)
        except Exception as exc:self.send('error',str(exc))
        finally:self.send('ended')

    def poll(self):
        try:
            while True:
                item=self.events.get_nowait();kind=item[0]
                if kind=='peak' and self.running:
                    peak,text,panel=item[1:]
                    selected,reason=resolve_marker(peak,panel,self.profiles)
                    if selected:
                        if self.vars['marker'].get()!=selected:
                            self.vars['marker'].set(selected);self.load_rule()
                        notes=review(peak,self.marker,self.rule)
                        if not peak.marker:notes.insert(0,reason)
                    else:
                        self.vars['marker'].set('');self.marker='';self.rule={}
                        for k in ('min_bp','max_bp','min_rfu','max_rfu'):self.vars[k].set('')
                        self.metadata.set(reason);notes=[reason+' Дүгнэлт өгөөгүй.']
                    notice=(peak,selected,tuple(notes))
                    if selected and any(n.startswith('Сэжигтэй:') for n in notes) and notice!=getattr(self,'last_notice',None):
                        self.last_notice=notice
                        if self.beep:
                            import winsound
                            winsound.MessageBeep(winsound.MB_ICONEXCLAMATION)
                    self.state.set('Panel: '+(panel or '—')+' · '+reason)
                    self.peak.set(f'{peak.size:g} bp  ·  {peak.height:g} RFU  ·  Point {peak.point}')
                    self.raw.set('OCR: '+text)
                    self.result.config(text='\n'.join(notes),bg='#fff0cb' if any(n.startswith('Сэжигтэй:') for n in notes) else '#edf2f7')
                elif kind in ('empty','error','state'):
                    self.state.set(item[1]);self.peak.set('Уншсан peak: —');self.result.config(text='Дүгнэлт өгөөгүй.',bg='#edf2f7');self.raw.set('OCR: '+(item[2] if len(item)>2 else '—'))
                elif kind=='ended':
                    self.running=False;self.btn.config(state='normal',text='Хяналт эхлүүлэх');self.peak.set('Уншсан peak: —');self.state.set('Зогссон.');self.result.config(text='Дүгнэлт өгөөгүй.',bg='#edf2f7')
        except queue.Empty:pass
        self.root.after(100,self.poll)

    def close(self):self.stop.set();self.root.destroy()


class FileAnalysis:
    """Local export watcher and review window; never edits the GeneMapper database."""
    def __init__(self, app):
        self.app=app;self.win=tk.Toplevel(app.root);self.win.title('PeakWatch 0.4.0 · Файлаас peak шинжлэх')
        self.win.geometry('1150x790');self.win.transient(app.root);self.paths=[];self.result=None;self.fsa={};self.watch=None;self.signature=None;self.pending=None;self.after_id=None
        self.settings_path=DATA/'analysis_settings.json'
        try:self.config=json.loads(self.settings_path.read_text(encoding='utf-8'))
        except (OSError,ValueError):self.config={}
        self.status=tk.StringVar(value='Samples болон Genotypes/Sizing TXT файлуудаа оруулна уу.')
        top=ttk.Frame(self.win,padding=8);top.pack(fill='x')
        ttk.Label(top,text='GeneMapper экспортын шинжилгээ · Урьдчилсан үнэлгээ',font=('Segoe UI',13,'bold')).pack(anchor='w')
        ttk.Label(top,text='Peak устгахгүй, GeneMapper-ийн allele-г өөрчлөхгүй. Hetero/homo нь санал; dropout болон артефактыг бүрэн үгүйсгэхгүй.',wraplength=1080).pack(anchor='w')
        bar=ttk.Frame(top);bar.pack(fill='x',pady=5)
        for label,cmd in [('TXT файлууд оруулах',self.choose),('Автомат хянах хавтас',self.folder),('Хавтас хяналт зогсоох',self.unwatch),('FSA ZIP / файлууд',self.choose_fsa),('Дүгнэлт JSON хадгалах',self.export)]:ttk.Button(bar,text=label,command=cmd).pack(side='left',padx=2)
        opts=ttk.LabelFrame(top,text='Лабораторид баталгаажсан босго — хоосон бол тухайн шалгалт идэвхгүй',padding=5);opts.pack(fill='x')
        fields=[('min_rfu','Min RFU'),('homo_min','Homo min RFU'),('balance_min','Hetero min ratio'),('stutter_max','Stutter max ratio'),('bp_tolerance','bp tolerance'),('pullup_max','Pull-up max ratio'),('point_tolerance','Scan tolerance')]
        self.vars={}
        for i,(key,label) in enumerate(fields):
            ttk.Label(opts,text=label).grid(row=0,column=i,padx=3)
            var=tk.StringVar(value=str(self.config.get(key,'')) if self.config.get(key) is not None else '')
            self.vars[key]=var;ttk.Entry(opts,textvariable=var,width=13).grid(row=1,column=i,padx=3)
        ttk.Button(opts,text='Хадгалж шинжлэх',command=self.reanalyze).grid(row=1,column=7,padx=4)
        ttk.Label(top,textvariable=self.status,wraplength=1090).pack(anchor='w',pady=5)
        book=ttk.Notebook(self.win);book.pack(fill='both',expand=True,padx=8)
        self.trees={};self.maps={}
        schemas={'summary':('Дээж / маркер',('sample','marker','dye','genotype','alleles','height_ratio','peak_count','flags')),
                 'peaks':('Бүх экспортолсон peak',('sample','marker','dye','size','height','allele','point','assignment','flags'))}
        for key,(title,cols) in schemas.items():
            frame=ttk.Frame(book);book.add(frame,text=title)
            tree=ttk.Treeview(frame,columns=cols,show='headings',selectmode='browse')
            for c in cols:tree.heading(c,text=c);tree.column(c,width=110 if c!='flags' else 320,stretch=False)
            y=ttk.Scrollbar(frame,orient='vertical',command=tree.yview);x=ttk.Scrollbar(frame,orient='horizontal',command=tree.xview)
            tree.configure(yscrollcommand=y.set,xscrollcommand=x.set);y.pack(side='right',fill='y');x.pack(side='bottom',fill='x');tree.pack(fill='both',expand=True)
            tree.tag_configure('review',background='#fff0cb');tree.bind('<<TreeviewSelect>>',lambda event,k=key:self.detail(k))
            self.trees[key]=tree
        rawframe=ttk.Frame(book);book.add(rawframe,text='FSA сувгийн мөр')
        ttk.Label(rawframe,text='Peak хүснэгтээс мөр сонгоход scan байрлалын ойр орчмыг харуулна. RAW = матриц/суурь шугам засварлаагүй; GeneMapper RFU-тай шууд адилтгахгүй.').pack(anchor='w')
        self.canvas=tk.Canvas(rawframe,bg='white',height=360);self.canvas.pack(fill='both',expand=True)
        helpframe=ttk.Frame(book);book.add(helpframe,text='Тайлбар')
        helptext='''HETERO_CANDIDATE: GeneMapper хоёр өөр нэртэй allele дуудсан.\nHOMO_CANDIDATE_DROPOUT_NOT_EXCLUDED: нэг нэртэй allele; dropout-ийг үгүйсгээгүй.\nREVIEW_REQUIRED / UNRESOLVED: гар аргаар шалгах шаардлагатай.\nSTUTTER_SUSPECT: нэг repeat-ээр бага, өгсөн өндрийн харьцаанд багтсан. Жинхэнэ allele ч байж болно.\nPULLUP_SUSPECT: өөр өнгийн хүчтэй peak-тэй scan байрлал ойролцоо, өгсөн ratio-д багтсан.\nPLUS_MINUS_A_SPACING: 1 bp орчим зай; +A/−A гэж батлаагүй.\nOFF_BIN: импортолсон bin хүрээнд ороогүй.\nCALLED_PEAKS_ONLY_OR_NO_SIZING_EXPORT: бүх peak-ийн Sizing хүснэгт байхгүй; артефакт шалгалт дутуу.\nRFU / BALANCE / HOMO_THRESHOLD_NOT_SET: тухайн босго оруулаагүй.\nPROFILE_UNMATCHED: Panel/Bin профайл дутуу эсвэл маркерийн нэр/өнгө зөрсөн.\nАвтомат хавтас: экспорт TXT нэмэгдэх/өөрчлөгдөх/устахад дахин уншина. GeneMapper-ийн дотоод өөрчлөлт экспортлогдоогүй бол энд харагдахгүй.\nГенотип нь зөвхөн GeneMapper-ийн нэртэй дуудлагад суурилна. Noise-оос шинэ allele автоматаар үүсгэхгүй.\nБосгуудыг нийтлэг утгаар тааж бөглөхгүй. Ratio нь 0–1, scan tolerance нь бүхэл тоо.'''
        ttk.Label(helpframe,text=helptext,wraplength=1050,justify='left').pack(anchor='nw',padx=12,pady=12)
        self.details=tk.Text(self.win,height=6,wrap='word');self.details.pack(fill='x',padx=8,pady=4)
        self.win.protocol('WM_DELETE_WINDOW',self.close)
    def choose(self):
        paths=filedialog.askopenfilenames(parent=self.win,title='Samples + Genotypes / Sizing TXT сонгоно',filetypes=[('GeneMapper export','*.txt *.tsv'),('All','*.*')])
        if paths:self.unwatch();self.paths=list(paths);self.load()
    def folder(self):
        path=filedialog.askdirectory(parent=self.win,title='GeneMapper TXT экспорт хадгалдаг хавтас')
        if not path:return
        self.unwatch();self.watch=Path(path);self.signature=None;self.pending=None;self.tick()
    def unwatch(self):
        self.watch=None
        if self.after_id:
            self.win.after_cancel(self.after_id);self.after_id=None
    def tick(self):
        self.after_id=None
        if not self.watch:return
        try:
            paths=sorted([p for p in self.watch.iterdir() if p.is_file() and p.suffix.lower() in ('.txt','.tsv')])
            sig=tuple((str(p),p.stat().st_mtime_ns,p.stat().st_size) for p in paths)
            if sig!=self.signature:
                if sig==self.pending:
                    self.paths=[str(p) for p in paths];self.load(folder=True);self.signature=sig;self.pending=None
                else:self.pending=sig;self.status.set('Хавтас өөрчлөгдсөн: файл бичигдэж дуусахыг хүлээж байна…')
        except OSError as exc:self.status.set('Хавтас унших алдаа: '+str(exc));self.result=None
        self.after_id=self.win.after(2000,self.tick)
    def options(self):
        from core import validate_analysis_options
        return validate_analysis_options({k:v.get().strip() for k,v in self.vars.items()})
    def load(self,folder=False):
        from core import read_export,analyze_exports
        try:
            options=self.options();exports=[];ignored=0
            for path in self.paths:
                try:exports.append(read_export(path))
                except ValueError as exc:
                    if folder and str(exc).startswith('Supported:'):ignored+=1;continue
                    raise ValueError(Path(path).name+': '+str(exc))
            if not exports:raise ValueError('Дэмжигдэх export TXT файл алга. Samples + Genotypes/Sizing сонгоно уу.')
            result=analyze_exports(exports,self.app.profiles,options)
            self.result=result
            for key,tree in self.trees.items():
                tree.delete(*tree.get_children());self.maps[key]={}
                rows=result['summaries'] if key=='summary' else result['peaks']
                for r in rows:
                    values=[]
                    for c in tree['columns']:
                        v=r.get(c,'')
                        if isinstance(v,list):v='; '.join(v)
                        elif isinstance(v,float):v=round(v,4)
                        values.append('' if v is None else v)
                    iid=tree.insert('','end',values=values,tags=('review',) if r['flags'] else ())
                    self.maps[key][iid]=r
            self.status.set(f"{len(result['samples'])} дээжийн мэдээлэл · {len(result['peaks'])} peak · {len(result['summaries'])} маркерийн мөр. Алгассан өөр TXT: {ignored}. "+('Хавтас хяналт идэвхтэй.' if self.watch else 'Файл импортолсон.'))
        except Exception as exc:
            self.result=None
            for tree in self.trees.values():tree.delete(*tree.get_children())
            self.status.set('Шинжилгээ хийгдээгүй: '+str(exc))
    def reanalyze(self):
        try:
            config=self.options();tmp=self.settings_path.with_suffix('.tmp');tmp.write_text(json.dumps(config),encoding='utf-8');tmp.replace(self.settings_path)
            self.load()
        except Exception as exc:messagebox.showerror('Босго',str(exc),parent=self.win)
    def choose_fsa(self):
        paths=filedialog.askopenfilenames(parent=self.win,title='FSA эсвэл эх ZIP файлаа сонгоно',filetypes=[('FSA / ZIP','*.fsa *.zip')])
        if not paths:return
        import zipfile
        try:
            index={}
            for path in paths:
                if Path(path).suffix.lower()=='.zip':
                    with zipfile.ZipFile(path) as z:
                        for info in z.infolist():
                            if not info.filename.lower().endswith('.fsa'):continue
                            if info.file_size>50*1024*1024:raise ValueError('FSA файл хэт том')
                            name=info.filename.replace('\\','/').rsplit('/',1)[-1]
                            if name in index:raise ValueError('Давхардсан FSA нэр: '+name)
                            index[name]=(path,info.filename)
                else:
                    name=Path(path).name
                    if name in index:raise ValueError('Давхардсан FSA нэр: '+name)
                    index[name]=(path,None)
            self.fsa=index;self.status.set(f'{len(index)} FSA холболоо. Peak хүснэгтээс мөр сонгоно уу.')
        except Exception as exc:messagebox.showerror('FSA',str(exc),parent=self.win)
    def detail(self,key):
        selection=self.trees[key].selection()
        if not selection:return
        row=self.maps[key].get(selection[0])
        if not row:return
        self.details.delete('1.0','end');self.details.insert('end',json.dumps(row,ensure_ascii=False,indent=2))
        if key=='peaks':self.draw_trace(row)
    def draw_trace(self,row):
        from core import read_abif
        import zipfile
        c=self.canvas;c.delete('all')
        try:
            if row['file'] not in self.fsa:raise ValueError('Энэ peak-ийн FSA холбогдоогүй. FSA ZIP / файлууд товчоор оруулна.')
            if row['point'] is None:raise ValueError('Data Point алга')
            path,member=self.fsa[row['file']]
            if member:
                with zipfile.ZipFile(path) as z:blob=z.read(member)
            else:blob=Path(path).read_bytes()
            traces=read_abif(blob);width=max(c.winfo_width(),850);height=max(c.winfo_height(),350)
            point=row['point'];lo=max(0,point-60);hi=point+60;lane=height/len(traces)
            colors=['#0046d5','#008000','#8f8500','#c60000','#c36d00']
            for i,trace in enumerate(traces):
                data=trace['data'];end=min(hi,len(data)-1)
                if end<=lo:continue
                values=data[lo:end+1];low=min(0,min(values));high=max(values);span=max(1,high-low)
                y0=i*lane+20;bottom=(i+1)*lane-5
                coords=[]
                for j,v in enumerate(values):coords.extend((120+(j/(hi-lo))*(width-140),bottom-(v-low)/span*(bottom-y0)))
                c.create_line(*coords,fill=colors[trace['channel']-1])
                x=120+(point-lo)/(hi-lo)*(width-140);c.create_line(x,y0,x,bottom,fill='#666',dash=(2,2))
                c.create_text(5,y0,anchor='nw',text=f"{trace['dye']} {trace['kind']}\n{trace['tag']} max {high}")
            c.create_text(width-10,5,anchor='ne',text=f'Scan {lo}–{hi}; босоо шугам = экспорт point {point} (0/1 суурь зөрүү боломжтой)')
        except Exception as exc:c.create_text(12,24,anchor='nw',text=str(exc),width=800)
    def export(self):
        if self.result is None:messagebox.showinfo('Экспорт','Амжилттай шинжилгээ эхлээд хийнэ.',parent=self.win);return
        path=filedialog.asksaveasfilename(parent=self.win,defaultextension='.json',initialfile='PeakWatch_review.json',filetypes=[('JSON','*.json')])
        if path:
            report=dict(self.result,version='0.4.0',scope='GeneMapper export review; not validated genotype determination',source_files=[Path(p).name for p in self.paths])
            Path(path).write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8')
    def close(self):self.unwatch();self.win.destroy()

if __name__=='__main__':
    if sys.platform!='win32':raise SystemExit('Windows 10/11 шаардлагатай. core.py шалгалтыг өөр системд ажиллуулж болно.')
    import ctypes
    try:ctypes.windll.user32.SetProcessDpiAwarenessContext(ctypes.c_void_p(-4))
    except Exception:pass
    App().root.mainloop()
