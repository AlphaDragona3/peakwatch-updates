"""Read GeneMapper labelled tab-separated panels/bins and explicit CSV tables.
Unknown/ambiguous rows fail the whole import; do not infer missing ranges.
"""
import csv, io, json, math
from pathlib import Path

class PanelError(ValueError):pass

def text_file(path):
    blob=Path(path).read_bytes()
    if len(blob)>10*1024*1024:raise PanelError('Файл 10 MB-аас том байна.')
    encs=['utf-16'] if blob.startswith((b'\xff\xfe',b'\xfe\xff')) else ['utf-8-sig','cp949','cp1252']
    for enc in encs:
        try:
            text=blob.decode(enc)
            if '\x00' in text:raise PanelError('Текст файл биш байна.')
            return text
        except UnicodeDecodeError:continue
    raise PanelError('Файлын кодчилол танигдсангүй.')

def norm(s):return ''.join(c for c in s.lower() if c.isalnum())

def num(s,field):
    try:v=float(s.strip().replace(',','.'))
    except (ValueError,AttributeError):raise PanelError(field+': тоо буруу')
    if not math.isfinite(v) or v<0:raise PanelError(field+': тоо буруу')
    return v

def key(kit,panel,name):return json.dumps([kit,panel,name],ensure_ascii=False,separators=(',',':'))

def label(record):return ' / '.join([record['kit'],record['panel'],record['marker_name']])

def marker(kit,panel,name,dye,lo,hi,repeat='',stutter='',control='',comments='',source=''):
    if not kit or not panel or not name:raise PanelError('Kit, Panel, Marker нэр дутуу.')
    colors={'blue':'Blue','green':'Green','yellow':'Yellow','red':'Red','purple':'Purple','orange':'Orange'}
    if dye.lower() not in colors:raise PanelError(name+': Dye Color танигдсангүй: '+dye)
    lo,hi=num(lo,'Min bp'),num(hi,'Max bp')
    if lo>=hi:raise PanelError(name+': Min bp нь Max bp-ээс бага байх ёстой.')
    return {'kit':kit,'panel':panel,'marker_name':name,'dye':colors[dye.lower()],
            'min_bp':lo,'max_bp':hi,'repeat_type_raw':repeat,'stutter_ratio_raw':stutter,
            'control_alleles_raw':control,'comments':comments,'source_file':source,
            'min_rfu':None,'max_rfu':None,'bins':[]}

def rows_of(text):
    delimiter='\t' if '\t' in text else ','
    return [(i,[v.strip() for v in row]) for i,row in enumerate(csv.reader(io.StringIO(text),delimiter=delimiter),1)
            if any(v.strip() for v in row) and not (row and row[0].lstrip().startswith('#'))]

def read_panels(path):
    rows=rows_of(text_file(path));result={};kit='';panel='';header=None;source=Path(path).name
    for line,c in rows:
        while c and not c[0]:c=c[1:]
        if not c:continue
        tag=norm(c[0]); val=c[1] if len(c)>1 else ''
        try:
            names=[norm(x) for x in c]
            if 'markername' in names and any(x in names for x in ('minsize','minbp','minasr')):
                header={n:i for i,n in enumerate(names)};continue
            if tag=='kittype':
                if val.upper()!='MICROSATELLITE':raise PanelError('Зөвхөн MICROSATELLITE Kit type дэмжинэ.')
                continue
            if tag in ('version','chemistry','datatype','analysissoftware','kitversion'):continue
            if tag in ('chemistrykit','kitname','kit'):kit=val;panel='';header=None;continue
            if tag in ('panelname','panel'):panel=val;header=None;continue
            if tag in ('binsetname','markername') and len(c)==2:raise PanelError('Энэ Bin файл байж болно; Bin оруулах товч ашиглана уу.')
            names=[norm(x) for x in c]
            if 'markername' in names and any(x in names for x in ('minsize','minbp','minasr')):
                header={n:i for i,n in enumerate(names)};continue
            if header is not None:
                def get(*aliases,default=''):
                    idx=next((header[a] for a in aliases if a in header),None)
                    return c[idx] if idx is not None and idx<len(c) else default
                rec=marker(get('kitname','chemistrykit','kit',default=kit),get('panelname','panel',default=panel),
                    get('markername','marker'),get('dyecolor','dye'),get('minsize','minbp','minasr'),get('maxsize','maxbp','maxasr'),
                    get('markerrepeat','markerrepeattype','repeattype'),get('markerspecificstutterratio','stutterratio'),
                    get('controlalleles'),get('comments'),source)
            elif len(c)>=4 and c[1].lower() in ('blue','green','yellow','red','purple','orange'):
                c=c+['']*max(0,8-len(c));rec=marker(kit,panel,c[0],c[1],c[2],c[3],c[5],c[6],c[4],c[7],source)
                rec['extra_fields_raw']=c[8:]
            else:raise PanelError('Танигдаагүй мөр. Labelled TXT эсвэл баганын нэртэй CSV/TSV шаардлагатай.')
            ident=label(rec)
            if ident in result:raise PanelError('Нэг Kit/Panel-д Marker нэр давхардсан.')
            result[ident]=rec
        except PanelError as exc:raise PanelError(f'{source}, мөр {line}: {exc}')
    if not result:raise PanelError('Маркер олдсонгүй.')
    return result

def read_bins(path):
    kit=panel=marker_name=binset='';result={};source=Path(path).name
    for line,c in rows_of(text_file(path)):
        while c and not c[0]:c=c[1:]
        tag=norm(c[0]);val=c[1] if len(c)>1 else ''
        try:
            if tag=='version':continue
            if tag in ('chemistrykit','kitname','kit'):kit=val;panel=marker_name='';continue
            if tag in ('binsetname','binset'):binset=val;continue
            if tag in ('panelname','panel'):panel=val;marker_name='';continue
            if tag in ('markername','marker'):
                marker_name=val
                if not all((kit,panel,marker_name,binset)):raise PanelError('Marker-ийн Kit/Panel/BinSet дутуу.')
                ident=' / '.join((kit,panel,marker_name))
                if ident in result:raise PanelError('Marker section давхардсан эсвэл олон BinSet байна.')
                result[ident]={'binset':binset,'bins':[]}
                continue
            if len(c)<4 or not all((kit,panel,marker_name,binset)):raise PanelError('Kit/Panel/Marker/BinSet бүтэц дутуу.')
            center,left,right=num(c[1],'Bin center'),num(c[2],'Left offset'),num(c[3],'Right offset')
            ident=' / '.join((kit,panel,marker_name));bucket=result.setdefault(ident,{'binset':binset,'bins':[]})
            if bucket['binset']!=binset:raise PanelError('Нэг маркерт олон BinSet байна; нэгийг нь тусад нь экспортлоно уу.')
            if any(b['name']==c[0] for b in bucket['bins']):raise PanelError('Bin нэр давхардсан.')
            bucket['bins'].append({'name':c[0],'center':center,'left_offset':left,'right_offset':right,'extra_fields_raw':c[4:]})
        except PanelError as exc:raise PanelError(f'{source}, мөр {line}: {exc}')
    if not result:raise PanelError('Bin олдсонгүй.')
    return result

def overlaps(records):
    values=list(records.values());notes=[]
    for i,a in enumerate(values):
        for b in values[i+1:]:
            if all(a.get(k)==b.get(k) for k in ('kit','panel','dye')) and max(a['min_bp'],b['min_bp'])<=min(a['max_bp'],b['max_bp']):
                notes.append(f"{a['marker_name']} ↔ {b['marker_name']}: {a['dye']} bp хүрээ давхцаж байна.")
    return notes

# Optional Windows-only, read-only Java accessibility transport.
# All table values remain in memory. No OCR, pointer tracking, export or database writes.
import ctypes as _ct
import time as _time
import re as _re
import sys as _sys

class _ContextInfo(_ct.Structure):
    _fields_=[('name',_ct.c_uint16*1024),('description',_ct.c_uint16*1024),
        ('role',_ct.c_uint16*256),('role_en_US',_ct.c_uint16*256),
        ('states',_ct.c_uint16*256),('states_en_US',_ct.c_uint16*256)]+[(n,_ct.c_int32) for n in
        ('indexInParent','childrenCount','x','y','width','height','accessibleComponent','accessibleAction','accessibleSelection','accessibleText','accessibleInterfaces')]
class _TableInfo(_ct.Structure):
    _fields_=[('caption',_ct.c_int64),('summary',_ct.c_int64),('rowCount',_ct.c_int32),('columnCount',_ct.c_int32),('accessibleContext',_ct.c_int64),('accessibleTable',_ct.c_int64)]
class _CellInfo(_ct.Structure):
    _fields_=[('accessibleContext',_ct.c_int64)]+[(n,_ct.c_int32) for n in ('index','row','column','rowExtent','columnExtent')]+[('isSelected',_ct.c_uint8)]
def _utf16(array):
    values=[]
    for c in array:
        if not c:break
        values.append(c)
    return b''.join(int(c).to_bytes(2,'little') for c in values).decode('utf-16-le',errors='replace')
def native_project(title):
    m=_re.match(r'^GeneMapper(?:[®™])?\s+Software\s+[^-]+?\s+-\s+(.+?)\s+\[[^\]]+\]\s+-\s+',title)
    return m[1] if m else ''
def bridge_candidates():
    import os
    roots=[Path(os.environ.get('SystemRoot',r'C:\Windows'))/'System32',
           Path(r'D:\AppliedBiosystems\GeneMapper'),Path(r'C:\AppliedBiosystems\GeneMapper')]
    if os.environ.get('JAVA_HOME'):roots.append(Path(os.environ['JAVA_HOME']))
    for var in ('ProgramFiles','ProgramFiles(x86)'):
        if os.environ.get(var):roots.append(Path(os.environ[var])/'Java')
    name='WindowsAccessBridge-64.dll' if _ct.sizeof(_ct.c_void_p)==8 else 'WindowsAccessBridge-32.dll'
    found=[]
    for root in roots:
        if not root.is_dir():continue
        if root.name=='System32':paths=[root/name]
        else:
            # Restrict discovery to the product/Java locations, never scan user documents.
            paths=[]
            for pattern in (name,'bin/'+name,'*/bin/'+name,'*/*/bin/'+name,'*/*/*/bin/'+name):
                paths.extend(root.glob(pattern))
        for p in paths:
            if p.is_file() and p not in found:found.append(p)
    return found

class JavaTableReader:
    def __init__(self):
        if _sys.platform!='win32':raise RuntimeError('Windows-only bridge')
        from ctypes import wintypes as W
        self.W=W;self.u=_ct.WinDLL('user32',use_last_error=True)
        self.u.GetWindowTextW.argtypes=[W.HWND,W.LPWSTR,_ct.c_int];self.u.GetWindowTextW.restype=_ct.c_int
        self.u.GetWindowThreadProcessId.argtypes=[W.HWND,_ct.POINTER(W.DWORD)];self.u.GetWindowThreadProcessId.restype=W.DWORD
        self.u.IsWindowVisible.argtypes=[W.HWND];self.u.IsWindowVisible.restype=W.BOOL
        self.u.GetForegroundWindow.restype=W.HWND
        self.d=None;errors=[]
        for path in bridge_candidates():
            try:self.d=_ct.CDLL(str(path),winmode=0x1100);self.dll=str(path);break
            except OSError as exc:errors.append(str(exc))
        if self.d is None:raise RuntimeError('JAVA_BRIDGE_UNAVAILABLE: таарах WindowsAccessBridge DLL олдсонгүй. Холболт батлагдаагүй.')
        def bind(name,args,ret):
            fn=getattr(self.d,name);fn.argtypes=args;fn.restype=ret;return fn
        I=_ct.c_int32;O=_ct.c_int64;B=_ct.c_int32
        self.run=bind('Windows_run',[],None)
        self.context=bind('getAccessibleContextFromHWND',[W.HWND,_ct.POINTER(I),_ct.POINTER(O)],B)
        self.info=bind('getAccessibleContextInfo',[I,O,_ct.POINTER(_ContextInfo)],B)
        self.child=bind('getAccessibleChildFromContext',[I,O,I],O)
        self.release=bind('releaseJavaObject',[I,O],None)
        self.table=bind('getAccessibleTableInfo',[I,O,_ct.POINTER(_TableInfo)],B)
        self.header=bind('getAccessibleTableColumnHeader',[I,O,_ct.POINTER(_TableInfo)],B)
        self.cell=bind('getAccessibleTableCellInfo',[I,O,I,I,_ct.POINTER(_CellInfo)],B)
        self.same=bind('isSameObject',[I,O,O],B)
        self.epoch=0;self.known=set();self.callbacks=[];self.setters=[]
        def callback5(vm,event,source,old,new):
            if vm in self.known:self.epoch+=1
            if event:self.release(vm,event)
            if source:self.release(vm,source)
        def callback3(vm,event,source):callback5(vm,event,source,None,None)
        self.run()
        for name,n,cb in [('setPropertyTableModelChangeFP',5,callback5),('setPropertyValueChangeFP',5,callback5),('setPropertyVisibleDataChangeFP',3,callback3)]:
            signature=_ct.CFUNCTYPE(None,I,O,O,*([_ct.c_void_p,_ct.c_void_p] if n==5 else []))
            wrapped=signature(cb);setter=bind(name,[_ct.c_void_p],None);setter(_ct.cast(wrapped,_ct.c_void_p))
            self.callbacks.append(wrapped);self.setters.append(setter)
        self.u.PeekMessageW.argtypes=[_ct.POINTER(W.MSG),W.HWND,W.UINT,W.UINT,W.UINT];self.u.PeekMessageW.restype=W.BOOL
        self.u.TranslateMessage.argtypes=[_ct.POINTER(W.MSG)];self.u.DispatchMessageW.argtypes=[_ct.POINTER(W.MSG)]
    def pump(self):
        msg=self.W.MSG();n=0
        while n<100 and self.u.PeekMessageW(_ct.byref(msg),None,0,0,1):
            self.u.TranslateMessage(_ct.byref(msg));self.u.DispatchMessageW(_ct.byref(msg));n+=1
    def windows(self):
        rows=[];W=self.W
        CB=_ct.WINFUNCTYPE(W.BOOL,W.HWND,W.LPARAM)
        def visit(hwnd,param):
            if not self.u.IsWindowVisible(hwnd):return True
            text=_ct.create_unicode_buffer(2048);self.u.GetWindowTextW(hwnd,text,2048)
            project=native_project(text.value)
            if project or text.value in ('Samples Plot','Genotypes Plot'):
                pid=W.DWORD();self.u.GetWindowThreadProcessId(hwnd,_ct.byref(pid));rows.append((hwnd,pid.value,text.value,project))
            return True
        cb=CB(visit);self.u.EnumWindows.argtypes=[CB,W.LPARAM];self.u.EnumWindows(cb,0)
        mains=[r for r in rows if r[3]]
        if len(mains)!=1:raise RuntimeError('Нэг GeneMapper project нээлттэй байх шаардлагатай; төслийг тааж сонгоогүй.')
        main=mains[0]
        return main[3],[r for r in rows if r[1]==main[1]]
    def _release_table(self,vm,t):
        # Every returned Java reference has its own retain; release each field, even aliases.
        for field in ('caption','summary','accessibleContext','accessibleTable'):
            value=getattr(t,field)
            if value:self.release(vm,value)
    def _value(self,vm,table,row,column):
        cell=_CellInfo()
        if not self.cell(vm,table,row,column,_ct.byref(cell)):raise RuntimeError('Хүснэгтийн нүд уншигдсангүй')
        try:
            info=_ContextInfo()
            if not self.info(vm,cell.accessibleContext,_ct.byref(info)):raise RuntimeError('Хүснэгтийн утга уншигдсангүй')
            return _utf16(info.name)
        finally:
            if cell.accessibleContext:self.release(vm,cell.accessibleContext)
    def snapshot(self,heartbeat):
        project,windows=self.windows();tables=[];start=_time.monotonic();nodes=0;calls=0
        epoch=self.epoch
        def read_table(vm,context):
            nonlocal calls
            table=_TableInfo();header=_TableInfo()
            if not self.table(vm,context,_ct.byref(table)):return
            try:
                if not 0<table.columnCount<=250 or not 0<=table.rowCount<=2000:return
                if not self.header(vm,context,_ct.byref(header)):return
                try:
                    if header.rowCount<1 or header.columnCount!=table.columnCount:return
                    names=[self._value(vm,header.accessibleTable,0,i) for i in range(table.columnCount)]
                finally:self._release_table(vm,header)
                if len(names)!=len(set(names)) or any(not n for n in names):return
                base=set(names)
                if not ({'Sample File','Sample Name','Panel'}<=base or ('Marker' in base and {'Size','Height','Data Point'}<=base)):return
                output=[]
                for row in range(table.rowCount):
                    value={}
                    for col,name in enumerate(names):
                        take=name in ('Sample File','Sample File Name','Sample Name','Panel','Marker','Dye','Dye/Sample Peak','Allele','Size','Height','Data Point','AE','OS','SPU','AN','BD','GQ') or bool(_re.fullmatch(r'Allele \d+',name))
                        if not take:continue
                        value[name]=self._value(vm,table.accessibleTable,row,col);calls+=1
                    for col,name in enumerate(names):
                        m=_re.fullmatch(r'(Size|Height|Data Point) (\d+)',name)
                        if m and value.get('Allele '+m[2],''):
                            value[name]=self._value(vm,table.accessibleTable,row,col);calls+=1
                    output.append(value)
                    self.pump();heartbeat()
                    if self.epoch!=epoch:raise RuntimeError('Хүснэгт унших явцад өөрчлөгдсөн; хуучин дүгнэлт ашиглаагүй.')
                    if calls>6000 or _time.monotonic()-start>20:raise RuntimeError('Уншилтын төсөв хэтэрсэн; дутуу хүснэгтээр дүгнээгүй.')
                tables.append(dict(headers=names,rows=output))
            finally:self._release_table(vm,table)
        def visit(vm,obj,depth):
            nonlocal nodes
            nodes+=1
            if nodes>500 or depth>16:return
            info=_ContextInfo()
            if not self.info(vm,obj,_ct.byref(info)):return
            role=_utf16(info.role_en_US)
            if 'password' in role.lower():return
            if role=='table':read_table(vm,obj);return
            for i in range(min(info.childrenCount,100)):
                child=self.child(vm,obj,i)
                if not child:continue
                try:visit(vm,child,depth+1)
                finally:self.release(vm,child)
            heartbeat();self.pump()
        for hwnd,pid,title,_ in windows:
            vm=_ct.c_int32();root=_ct.c_int64()
            if self.context(hwnd,_ct.byref(vm),_ct.byref(root)):
                self.known.add(vm.value)
                try:visit(vm.value,root.value,0)
                finally:self.release(vm.value,root.value)
        if self.windows()[0]!=project or self.epoch!=epoch:raise RuntimeError('Төсөл/хүснэгт солигдсон; өмнөх төслийн дүгнэлт ашиглаагүй.')
        if not tables:raise RuntimeError('LIVE_TABLE_UNAVAILABLE: GeneMapper хүснэгт Java Access Bridge-ээр харагдсангүй. Шууд холболт батлагдаагүй.')
        return dict(project=project,tables=tables,epoch=self.epoch)
    def close(self):
        for setter in self.setters:setter(None)
        self.pump()

def native_read_worker(output,stop):
    from core import setup_diagnostics
    from updater import DATA
    logger,fault_handle=setup_diagnostics(DATA,'reader')
    reader=None
    def send(kind,value):
        try:output.put_nowait((kind,value))
        except Exception:pass
    last_beat=[0]
    def heartbeat():
        now=_time.monotonic()
        if now-last_beat[0]>.5:send('heartbeat',now);last_beat[0]=now
    try:
        reader=JavaTableReader();last=-1;last_project='';settle=0;retry_at=0;last_error=''
        while not stop.wait(.1):
            reader.pump();heartbeat()
            try:project,_=reader.windows()
            except RuntimeError as exc:
                if last_error!=str(exc):send('invalid',str(exc));last_error=str(exc)
                last_project=''
                continue
            last_error=''
            if reader.epoch!=last or project!=last_project:
                if not settle:settle=_time.monotonic()+.8
                if _time.monotonic()<max(settle,retry_at):continue
                send('invalid','Хүснэгт шинэчлэгдэж байна…')
                try:
                    data=reader.snapshot(heartbeat);send('snapshot',data);last=reader.epoch;last_project=project;settle=0
                except RuntimeError as exc:
                    send('invalid',str(exc));retry_at=_time.monotonic()+10;settle=0
    except Exception as exc:
        logger.exception('Reader blocked')
        send('blocked',str(exc))
    finally:
        if reader:reader.close()
