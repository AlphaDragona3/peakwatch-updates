@echo off
cd /d "%~dp0"
if not exist ".venv\Scripts\pythonw.exe" (
  py -3.11 -m venv .venv
  if errorlevel 1 (
    echo Python 3.11 is required.
    pause
    exit /b 1
  )
)
start "" ".venv\Scripts\pythonw.exe" "%~dp0launcher.py"
exit /b 0
