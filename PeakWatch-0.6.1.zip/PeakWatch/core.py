"""Strict parser and limited review rules; no allele classification."""
import re
import math
from dataclasses import dataclass

@dataclass(frozen=True)
class Peak:
    point: int
    size: float
    height: float
    marker: str = ''
    allele: str = ''

def parse_status(text):
    # Both observed GeneMapper status layouts. X/Y is never a peak measurement.
    number=r'(\d+(?:\.\d+)?)'
    pattern=r'\bData\s+Point\s*:?\s*(\d+)\s+Size\s*:?\s*'+number+r'\s+Height\s*:?\s*'+number+r'(?=\s|\]|$)'
    matches=list(re.finditer(pattern,text,re.I))
    if len(matches)!=1:return None
    match=matches[0]
    marker=re.search(r'\bMarker\s*:?\s*([A-Za-z][A-Za-z0-9_*.-]*)',text,re.I)
    allele=re.search(r'\bAllele\s*:?\s*([^\]\s]+)',text,re.I)
    classic=bool(re.search(r'\bPeak\s*:\s*$',text[:match.start()],re.I))
    if not classic and not (marker and allele):return None
    point,size,height=int(match[1]),float(match[2]),float(match[3])
    if not (0<point<10000000 and 0<size<20000 and 0<=height<100000000):return None
    return Peak(point,size,height,marker[1] if marker else '',allele[1] if allele else '')

def validate_rule(rule):
    for key in ('min_bp', 'max_bp', 'min_rfu', 'max_rfu'):
        val = rule.get(key)
        if val is not None and (not isinstance(val, (int, float)) or not math.isfinite(val) or val < 0):
            raise ValueError('Босго нь тэгээс багагүй тоо байх ёстой.')
    for a,b in [('min_bp','max_bp'),('min_rfu','max_rfu')]:
        if rule.get(a) is not None and rule.get(b) is not None and rule[a] > rule[b]:
            raise ValueError('Доод босго дээд босгоос их байна.')
    return rule

def review(peak, marker, rule):
    notes = []
    if not marker:
        return ['Маркер баталгаажаагүй: дүгнэлт өгөөгүй.']
    if peak.marker and peak.marker.casefold() != marker.casefold():
        return ['Маркер зөрсөн: тохиргоог энэ peak-д хэрэглээгүй.']
    if peak.allele == '?':
        notes.append('GeneMapper allele = ?: аллелийн нэр/bin-ийг шалгана уу.')
    if not rule or not any(rule.get(k) is not None for k in ('min_bp','max_bp','min_rfu','max_rfu')):
        notes.append('Баталгаажсан bp/RFU босго оруулаагүй: тоон шалгалт хийгдээгүй.')
        return notes
    validate_rule(rule)
    for key, value, predicate, label in [
        ('min_bp',peak.size,lambda x,y:x<y,'bp доод хязгаараас бага'),
        ('max_bp',peak.size,lambda x,y:x>y,'bp дээд хязгаараас их'),
        ('min_rfu',peak.height,lambda x,y:x<y,'RFU доод босгоос бага'),
        ('max_rfu',peak.height,lambda x,y:x>y,'RFU дээд босгоос их')]:
        if rule.get(key) is not None and predicate(value,rule[key]):
            notes.append(f'Сэжигтэй: {label} ({value:g}; босго {rule[key]:g}).')
    bins=rule.get('bins',[])
    if bins and not any(b['center']-b['left_offset'] <= peak.size <= b['center']+b['right_offset'] for b in bins):
        notes.append('Сэжигтэй: оруулсан BinSet-ийн bin хүрээнд орохгүй байна. BinSet-ээ шалгана уу.')
    if rule.get('min_bp') is not None and rule.get('max_bp') is not None:
        if rule['min_bp']<=peak.size<=rule['max_bp']:
            notes.append(f"bp: маркерийн {rule['min_bp']:g}–{rule['max_bp']:g} хүрээнд байна.")
    if rule.get('min_rfu') is None and rule.get('max_rfu') is None:
        notes.append('RFU: босго оруулаагүй — өндрийн чанарыг үнэлээгүй.')
    if not bins:notes.append('Bin: энэ маркерт bin байхгүй — allele нэр баталгаажуулаагүй.')
    else:
        matches=[b for b in bins if b['center']-b['left_offset']<=peak.size<=b['center']+b['right_offset']]
        if len(matches)==1:notes.append('Bin: '+str(matches[0]['name'])+' хүрээнд таарсан (аллель баталгаа биш).')
        elif len(matches)>1:notes.append('Сэжигтэй: олон bin хүрээ давхцсан.')
    return notes or ['Оруулсан bp/RFU босго зөрчөөгүй. Аллель зөв гэдгийг батлахгүй.']


def detect_panel(text, profiles):
    """Exact known panel tokens only; ambiguous header gives no context."""
    found={r.get('panel') for r in profiles.values() if r.get('panel') and
           re.search(r'(?<![A-Za-z0-9_])'+re.escape(r['panel'])+r'(?![A-Za-z0-9_])',text,re.I)}
    return next(iter(found)) if len(found)==1 else ''

def resolve_marker(peak, panel, profiles):
    """Never reuse a stale manual rule or guess among dyes/kits."""
    if not panel and not peak.marker:return None, 'Panel/Marker харагдаагүй: маркер сонгоогүй.'
    candidates=[(k,r) for k,r in profiles.items() if not panel or r.get('panel','').casefold()==panel.casefold()]
    if peak.marker:
        candidates=[(k,r) for k,r in candidates if r.get('marker_name','').casefold()==peak.marker.casefold()]
    else:
        candidates=[(k,r) for k,r in candidates if r.get('min_bp') is not None and r.get('max_bp') is not None and r['min_bp']<=peak.size<=r['max_bp']]
    if len(candidates)==1:
        return candidates[0][0], (('Status Marker ганц профайлтай таарсан; Panel нэр дэлгэцэд харагдаагүй.' if not panel else 'Status маркераар автоматаар сонгосон.') if peak.marker else 'Panel + bp хүрээний цорын ганц маркер. Өнгө баталгаажаагүй.')
    return None, ('Олон маркер таарч байна: автоматаар сонгоогүй.' if candidates else 'Panel дотор тохирох маркер олдсонгүй.')

# File-based analysis uses GeneMapper export measurements, never screenshot coordinates.
import csv
import io
import struct
from pathlib import Path
from collections import defaultdict

DYE_NAMES={'b':'Blue','g':'Green','y':'Yellow','r':'Red','o':'Orange','p':'Purple',
           'blue':'Blue','green':'Green','yellow':'Yellow','red':'Red','orange':'Orange','purple':'Purple'}

def read_export(path):
    from panels import text_file
    return parse_export_text(text_file(path),Path(path).name)

def parse_export_text(text,source_name='live-memory'):
    reader=csv.DictReader(io.StringIO(text),delimiter='\t')
    headers=reader.fieldnames or []
    rows=list(reader)
    if len(rows)>200000:raise ValueError('Export exceeds 200000 rows')
    def number(value):
        if not str(value or '').strip():return None
        v=float(value)
        if not math.isfinite(v) or v<0:raise ValueError('Invalid export measurement: '+str(value))
        return v
    def point(value):
        v=number(value)
        if v is not None and v!=int(v):raise ValueError('Data Point must be an integer')
        return int(v) if v is not None else None
    peaks=[];samples={};groups=set()
    if {'Sample File Name','Dye/Sample Peak','Size','Height','Data Point'}<=set(headers):
        kind='sizing'
        for row in rows:
            filename=row['Sample File Name'].strip()
            dye=DYE_NAMES.get(row['Dye/Sample Peak'].split(',')[0].strip().lower())
            if not filename or not dye:raise ValueError('Missing file or unknown dye')
            peaks.append(dict(file=filename,sample='',panel='',marker=row.get('Marker','').strip(),dye=dye,
                allele=row.get('Allele','').strip(),size=number(row['Size']),height=number(row['Height']),
                area=number(row.get('Area')),point=point(row['Data Point']),source=source_name,kind=kind))
    elif {'Sample File','Marker','Dye'}<=set(headers) and any(re.fullmatch(r'Size \d+',c) for c in headers):
        kind='genotypes'
        indices=[c.split()[-1] for c in headers if re.fullmatch(r'Size \d+',c)]
        for row in rows:
            filename=row['Sample File'].strip();marker=row['Marker'].strip()
            if not filename or not marker:raise ValueError('Missing genotype file or marker')
            samples[filename]={'sample':row.get('Sample Name','').strip(),'panel':row.get('Panel','').strip()}
            dye=DYE_NAMES.get(row['Dye'].lower().strip())
            if not dye:raise ValueError('Unknown dye')
            groups.add((filename,marker,dye))
            for i in indices:
                values=[row.get(c+' '+i,'').strip() for c in ('Allele','Size','Height','Data Point')]
                if not any(values):continue
                peaks.append(dict(file=filename,sample=samples[filename]['sample'],panel=samples[filename]['panel'],
                    marker=marker,dye=dye,allele=values[0],size=number(values[1]),height=number(values[2]),
                    area=number(row.get('Peak Area '+i)),point=point(values[3]),source=source_name,kind=kind))
    elif {'Sample File','Sample Name','Panel'}<=set(headers):
        kind='samples'
        for row in rows:
            filename=row['Sample File'].strip()
            if filename in samples and samples[filename]['panel']!=row['Panel'].strip():raise ValueError('Conflicting sample panels')
            samples[filename]={'sample':row['Sample Name'].strip(),'panel':row['Panel'].strip()}
    else:raise ValueError('Supported: Samples / Genotypes / Sizing export TXT')
    return dict(kind=kind,peaks=peaks,samples=samples,groups=groups,rows=len(rows))

def combine_exports(exports):
    samples={};seen={};groups=set();warnings=[]
    for export in exports:
        for filename,meta in export['samples'].items():
            old=samples.get(filename)
            if old and old['panel'] and meta['panel'] and old['panel']!=meta['panel']:
                raise ValueError('Conflicting panels for '+filename)
            samples[filename]={'sample':meta['sample'] or (old or {}).get('sample',''),
                               'panel':meta['panel'] or (old or {}).get('panel','')}
        groups.update(export['groups'])
        for p in export['peaks']:
            # Exported data point is the identity; retain distinct marker assignments on a collision.
            k=(p['file'],p['dye'],p['point'],p['marker'])
            if p['point'] is None:k+=(p['size'],p['height'],p['allele'])
            if k in seen:
                old=seen[k]
                for field in ('size','height','allele'):
                    if old[field] is not None and p[field] is not None and old[field]!=p[field]:
                        raise ValueError('Conflicting export values: '+p['file']+' '+str(p['point']))
                if p['kind']=='genotypes':seen[k]=dict(p)
            else:seen[k]=dict(p)
    peaks=list(seen.values())
    for p in peaks:
        p.update(samples.get(p['file'],{'sample':p['sample'],'panel':p['panel']}))
        p['full_peak_table']=any(e['kind']=='sizing' and any(q['file']==p['file'] for q in e['peaks']) for e in exports)
    return peaks,samples,groups

def validate_analysis_options(options):
    result={}
    for key in ('min_rfu','homo_min','balance_min','stutter_max','bp_tolerance','pullup_max','point_tolerance'):
        v=options.get(key)
        if v is None or v=='':result[key]=None;continue
        v=float(v)
        if not math.isfinite(v) or v<0:raise ValueError('Invalid setting: '+key)
        if key.endswith(('_min','_max')) and key in ('balance_min','stutter_max','pullup_max') and v>1:raise ValueError('Ratio must be 0–1')
        if key=='point_tolerance' and v!=int(v):raise ValueError('Scan tolerance must be an integer')
        result[key]=v
    return result

def analyze_exports(exports,profiles,options=None):
    options=validate_analysis_options(options or {})
    peaks,samples,empty_groups=combine_exports(exports)
    by_file=defaultdict(list);by_marker=defaultdict(list)
    for filename,meta in samples.items():
        for rule in profiles.values():
            if rule.get('panel')==meta['panel']:
                empty_groups.add((filename,rule['marker_name'],rule['dye']))
    for p in peaks:
        p['flags']=[];p['links']=[];p['profile']=None;p['assignment']='unassigned'
        if p['height'] is None:p['flags'].append('HEIGHT_MISSING')
        if p['size'] is None:p['flags'].append('SIZE_MISSING')
        candidates=[(k,r) for k,r in profiles.items() if p['panel'] and r.get('panel')==p['panel'] and r.get('dye')==p['dye']]
        if p['marker']:
            candidates=[(k,r) for k,r in candidates if r.get('marker_name')==p['marker']]
            p['assignment']='GeneMapper'
        elif p['size'] is not None:
            candidates=[(k,r) for k,r in candidates if r['min_bp']<=p['size']<=r['max_bp']]
            if len(candidates)==1:
                p['marker']=candidates[0][1]['marker_name'];p['assignment']='panel+dye+bp'
        else:candidates=[]
        if len(candidates)==1:
            p['profile']=candidates[0][0];rule=candidates[0][1]
            if p['size'] is not None:
                if not rule['min_bp']<=p['size']<=rule['max_bp']:p['flags'].append('OUTSIDE_MARKER')
                bins=rule.get('bins',[])
                if bins:
                    matches=[b for b in bins if b['center']-b['left_offset']<=p['size']<=b['center']+b['right_offset']]
                    if not matches:p['flags'].append('OFF_BIN')
                    if len(matches)>1:p['flags'].append('BIN_OVERLAP')
        elif len(candidates)>1:p['flags'].append('MARKER_AMBIGUOUS')
        else:p['flags'].append('PROFILE_UNMATCHED')
        rule=profiles.get(p['profile'],{})
        threshold=options['min_rfu'] if options['min_rfu'] is not None else rule.get('min_rfu')
        p['effective_min_rfu']=threshold;p['effective_max_rfu']=rule.get('max_rfu')
        if p['height'] is not None and rule.get('max_rfu') is not None and p['height']>rule['max_rfu']:p['flags'].append('ABOVE_RFU')
        if threshold is not None and p['height'] is not None and p['height']<threshold:p['flags'].append('BELOW_RFU')
        if p['allele']=='?':p['flags'].append('ALLELE_UNKNOWN')
        by_file[p['file']].append(p)
        if p['marker']:by_marker[(p['file'],p['marker'],p['dye'])].append(p)
    def link(p,kind,parent,ratio,delta):
        p['flags'].append(kind)
        p['links'].append(dict(kind=kind,parent_marker=parent['marker'],parent_dye=parent['dye'],
                               parent_point=parent['point'],ratio=round(ratio,6),delta=round(delta,4)))
    # These comparisons only flag hypotheses. No peak is deleted or silently demoted.
    for group in by_marker.values():
        for p in group:
            if p['size'] is None or not p['height'] or not p['profile']:continue
            repeat=profiles[p['profile']].get('repeat_type_raw','')
            try:repeat=float(repeat)
            except (ValueError,TypeError):repeat=None
            for parent in group:
                if parent is p or parent['size'] is None or not parent['height'] or parent['height']<=p['height']:continue
                delta=parent['size']-p['size'];ratio=p['height']/parent['height']
                tol=options['bp_tolerance']
                if tol is not None and options['stutter_max'] is not None and repeat and abs(delta-repeat)<=tol and ratio<=options['stutter_max']:
                    link(p,'STUTTER_SUSPECT',parent,ratio,delta)
                if tol is not None and abs(abs(delta)-1)<=tol:
                    link(p,'PLUS_MINUS_A_SPACING',parent,ratio,delta)
    for group in by_file.values():
        if options['point_tolerance'] is None or options['pullup_max'] is None:continue
        for p in group:
            if p['point'] is None or not p['height']:continue
            for parent in group:
                if parent['dye']==p['dye'] or parent['point'] is None or not parent['height'] or parent['height']<=p['height']:continue
                delta=abs(parent['point']-p['point']);ratio=p['height']/parent['height']
                if delta<=options['point_tolerance'] and ratio<=options['pullup_max']:
                    link(p,'PULLUP_SUSPECT',parent,ratio,delta)
    summaries=[]
    for identity in sorted(set(by_marker)|empty_groups):
        group=by_marker.get(identity,[])
        called=[p for p in group if p['allele'] and p['allele'] not in ('?','OL','Off Ladder')]
        alleles=sorted({p['allele'] for p in called})
        heights=[p['height'] for p in called if p['height'] is not None]
        ratio=min(heights)/max(heights) if len(heights)>=2 and max(heights)>0 else None
        flags=sorted({flag for p in group for flag in p['flags']})
        if len(alleles)==2:state='HETERO_CANDIDATE'
        elif len(alleles)==1:state='HOMO_CANDIDATE_DROPOUT_NOT_EXCLUDED'
        elif len(alleles)>2:state='MULTI_ALLELE_REVIEW'
        else:state='UNRESOLVED'
        if any(f in flags for f in ('STUTTER_SUSPECT','PULLUP_SUSPECT','PLUS_MINUS_A_SPACING','OFF_BIN','MARKER_AMBIGUOUS','OUTSIDE_MARKER','BELOW_RFU','ABOVE_RFU','PROFILE_UNMATCHED','ALLELE_UNKNOWN','SIZE_MISSING','HEIGHT_MISSING')):state='REVIEW_REQUIRED'
        if len(called)!=len(alleles):
            flags.append('DUPLICATE_ALLELE_PEAKS');state='REVIEW_REQUIRED'
        if not group:flags.append('NO_EXPORTED_PEAKS')
        if re.search(r'AME|ZFX|ZFY|SRY|AMEL',identity[1],re.I):
            flags.append('SEX_MARKER_MODEL_NOT_DEFINED');state='UNRESOLVED'
        if not called:flags.append('NO_NAMED_ALLELE')
        if any(p['assignment']!='GeneMapper' for p in group):flags.append('INFERRED_MARKER_ASSIGNMENT')
        if not any(p['full_peak_table'] for p in group):flags.append('CALLED_PEAKS_ONLY_OR_NO_SIZING_EXPORT')
        if options['min_rfu'] is None and not any(p.get('effective_min_rfu') is not None for p in group):flags.append('RFU_THRESHOLD_NOT_SET')
        if len(alleles)==2:
            if ratio is None:flags.append('BALANCE_UNAVAILABLE');state='REVIEW_REQUIRED'
            elif options['balance_min'] is None:flags.append('BALANCE_THRESHOLD_NOT_SET')
            elif ratio<options['balance_min']:flags.append('IMBALANCED');state='REVIEW_REQUIRED'
        if len(alleles)==1:
            if options['homo_min'] is None:flags.append('HOMO_THRESHOLD_NOT_SET')
            elif not heights or max(heights)<options['homo_min']:flags.append('LOW_HOMO_HEIGHT');state='REVIEW_REQUIRED'
        summaries.append(dict(file=identity[0],sample=samples.get(identity[0],{}).get('sample',''),marker=identity[1],dye=identity[2],
            genotype=state,alleles='/'.join(alleles),height_ratio=ratio,peak_count=len(group),flags=sorted(set(flags))))
    return dict(peaks=peaks,summaries=summaries,samples=samples,options=options)

def read_abif(blob):
    """Bounded ABIF directory reader, preserving raw vs analysed trace distinction."""
    if len(blob)>50*1024*1024 or len(blob)<34 or blob[:4]!=b'ABIF':raise ValueError('Invalid/oversized ABIF file')
    entry=struct.Struct('>4sIHHIIII')
    root=entry.unpack_from(blob,6);count,offset=root[4],root[6]
    if count>10000 or offset+28*count>len(blob):raise ValueError('Invalid ABIF directory')
    tags={}
    for i in range(count):
        pos=offset+i*28;tag,num,typ,width,n,size,off,_=entry.unpack_from(blob,pos)
        if size>50*1024*1024 or (size>4 and off+size>len(blob)):raise ValueError('Invalid ABIF data bounds')
        data=blob[pos+20:pos+24][:size] if size<=4 else blob[off:off+size]
        key=tag.decode('ascii')+str(num)
        if key in tags:raise ValueError('Duplicate ABIF tag')
        if typ==4:
            if size!=n*2:raise ValueError('Invalid ABIF short array')
            value=struct.unpack('>'+str(n)+'h',data)
        elif typ==18:value=data[1:1+data[0]].decode('latin1') if data else ''
        elif typ==19:value=data.rstrip(b'\0').decode('latin1')
        else:value=data
        tags[key]=value
    traces=[]
    for channel in range(1,6):
        raw='DATA'+str(channel if channel<5 else 105)
        analysed='DATA'+str(channel+8 if channel<5 else 205)
        for key,kind in ((raw,'RAW'),(analysed,'ANALYSED')):
            data=tags.get(key)
            if isinstance(data,tuple):traces.append(dict(channel=channel,dye=tags.get('DyeN'+str(channel),str(channel)),kind=kind,tag=key,data=data))
    if not traces:raise ValueError('No supported ABIF trace arrays')
    return traces


def add_replicate_checks(result):
    """Same sample name + panel is a comparison group, not proof of a lab replicate."""
    groups=defaultdict(list)
    for row in result['summaries']:
        meta=result['samples'].get(row['file'],{})
        if meta.get('sample') and meta.get('panel'):
            groups[(meta['sample'],meta['panel'],row['marker'],row['dye'])].append(row)
    for rows in groups.values():
        if len({r['file'] for r in rows})<2:continue
        calls={frozenset(r['alleles'].split('/')) for r in rows if r['alleles']}
        flag='REPLICATE_DISCORDANCE' if len(calls)>1 else ('REPLICATE_MISSING_CALL' if calls and any(not r['alleles'] for r in rows) else None)
        if flag:
            for row in rows:
                row['flags']=sorted(set(row['flags']+[flag]));row['genotype']='REVIEW_REQUIRED'
    return result


def match_live_peak(peak,header_text,result,panel=''):
    """No nearest-neighbour matching. Sample identity AND exported measurements must agree."""
    if result is None:return None,'Өгөгдөл холбогдоогүй эсвэл файл өөрчлөгдсөн. TXT эх үүсвэрээ холбоно уу.'
    samples=result['samples']
    files=[filename for filename in samples if filename.casefold() in header_text.casefold()]
    if not files:
        # Recognize exact sample tokens, including parentheses, without prefix collisions.
        aliases={m['sample'] for m in samples.values() if m.get('sample')}
        names={name for name in aliases if re.search(r'(?<![A-Za-z0-9_(])'+re.escape(name)+r'(?![A-Za-z0-9_)])',header_text,re.I)}
        if len(names)!=1:return None,'Дээжийн нэр тодорхой танигдаагүй. Samples Plot-ийн Sample Name баганыг харуулна уу.'
        name=next(iter(names));files=[f for f,m in samples.items() if m.get('sample')==name]
    if panel:files=[f for f in files if samples[f].get('panel','').casefold()==panel.casefold()]
    candidates=[p for p in result['peaks'] if p['file'] in files and p['point']==peak.point and
                p['size'] is not None and abs(p['size']-peak.size)<=.011 and
                p['height'] is not None and p['height']==peak.height and
                (not peak.marker or p['marker'].casefold()==peak.marker.casefold()) and
                (not peak.allele or p['allele']==peak.allele)]
    # A duplicate same-file/point export is also ambiguous if it has multiple assignments.
    if len(candidates)!=1:
        return None,('Ижил хэмжилт олон файлд таарсан — дүгнэлт хольж харуулахгүй.' if candidates else
                     'Энэ peak экспорттой таарахгүй. Дээж/шинжилгээ өөрчлөгдсөн бол TXT-ээ дахин экспортлоно уу.')
    p=candidates[0]
    row=next((s for s in result['summaries'] if s['file']==p['file'] and s['marker']==p['marker'] and s['dye']==p['dye']),None)
    if not row:return None,'Экспортод энэ маркерийн дүгнэлт алга.'
    return dict(peak=p,summary=row),'Дээж + Data Point + bp + RFU экспортоор таарсан.'


def live_recommendations(match,result):
    """Evidence, uncertainty and next action. No unvalidated 'PCR failed' assertion."""
    p=match['peak'];row=match['summary'];flags=set(p['flags'])|set(row['flags'])
    labels={'HETERO_CANDIDATE':'Hetero санал: хоёр өөр нэртэй allele',
            'HOMO_CANDIDATE_DROPOUT_NOT_EXCLUDED':'Homo санал: нэг нэртэй allele; dropout үгүйсгээгүй',
            'MULTI_ALLELE_REVIEW':'Хоёроос олон allele: шалгах',
            'UNRESOLVED':'Генотип тодорхойлоогүй', 'REVIEW_REQUIRED':'Гар аргаар шалгах шаардлагатай'}
    lines=[f"Дээж: {p['sample'] or row['sample']} · Panel: {p['panel']}",
           f"Маркер: {p['marker']} · {p['dye']} · allele: {p['allele'] or '—'}",
           labels.get(row['genotype'],row['genotype'])+f" ({row['alleles'] or 'нэртэй allele алга'})"]
    if row['height_ratio'] is not None:lines.append(f"Peak height ratio: {row['height_ratio']:.3f}")
    actions=[]
    if 'PULLUP_SUSPECT' in p['flags']:
        lines.append('Сэжиг: өөр өнгийн өндөр peak-тэй scan давхцсан.')
        actions.append('Өнгийн сувгууд болон spectral correction-ийг шалга; хүчтэй дохио бол шингэлэлт/CE давталтыг авч үз.')
    if 'STUTTER_SUSPECT' in p['flags']:
        lines.append('Сэжиг: нэг repeat-ээр бага peak, өгсөн stutter ratio-д багтсан.')
        actions.append('Хажуугийн allele болон marker-ийн stutter босгоор шалга; шууд устгахгүй.')
    if 'PLUS_MINUS_A_SPACING' in p['flags']:
        lines.append('Сэжиг: ~1 bp зайтай хос peak (+A/−A байж болно).')
        actions.append('Хос peak-ийн хэлбэр, PCR-ийн adenylation нөхцөлийг шалга.')
    if 'OFF_BIN' in flags or 'ALLELE_UNKNOWN' in flags:
        lines.append('Аллелийн нэр/bin баталгаажаагүй.')
        actions.append('Bin, panel, sizing-ийг шалга; зөвхөн ? тэмдэгтээс PCR дахин хийх шийдвэр гаргахгүй.')
    if 'SIZE_MISSING' in flags:
        actions.append('Size standard ба sizing curve-ийг дахин шалга; засах боломжгүй бол CE давталтыг авч үз.')
    if flags&{'BELOW_RFU','LOW_HOMO_HEIGHT','IMBALANCED'}:
        lines.append('Чанар: тохируулсан RFU/PHR босго зөрчсөн.')
        actions.append('Сул allele/dropout эсвэл тэнцвэргүй дохио: ДНХ оролт, control-оо шалгаад давтан шинжилгээг авч үз.')
    if 'ABOVE_RFU' in flags:
        lines.append('Чанар: маркерийн max RFU босгоос өндөр.')
        actions.append('Дохио хэт өндөр: raw saturation болон шингэлэлтийг шалга; CE давталтыг авч үз.')
    if flags&{'REPLICATE_DISCORDANCE','REPLICATE_MISSING_CALL'}:
        lines.append('Нэр ижил файлуудын allele дуудлага зөрсөн/дутуу.')
        actions.append('Файлууд ижил дээжийн давталт мөн эсэх, шингэлэлтийг шалга; зөрүү батлагдвал давтан шинжилгээг авч үз.')
    if flags&{'PROFILE_UNMATCHED','MARKER_AMBIGUOUS','OUTSIDE_MARKER'}:
        actions.append('Panel/маркер/өнгөний холбоосыг засаж байж дүгнэнэ.')
    coverage=[]
    for option,title in [('min_rfu','RFU'),('balance_min','hetero PHR'),('homo_min','homo RFU'),('stutter_max','stutter'),('pullup_max','pull-up')]:
        if result['options'].get(option) is None and not (option=='min_rfu' and p.get('effective_min_rfu') is not None):coverage.append(title)
    if coverage:lines.append('Идэвхгүй босго: '+', '.join(coverage))
    if 'CALLED_PEAKS_ONLY_OR_NO_SIZING_EXPORT' in flags:
        lines.append('Бүх peak-ийн хүснэгт дутуу: харагдахгүй артефактыг үгүйсгэхгүй.')
    for link in p['links'][:3]:
        lines.append(f"↳ {link['parent_marker'] or 'маркергүй'} / {link['parent_dye']} / scan {link['parent_point']}: ratio {link['ratio']:.3f}, зай {link['delta']:g}")
    lines.append('Хийх алхам: '+(' '.join(dict.fromkeys(actions)) if actions else 'Одоогийн мэдээллээр давтан шинжилгээ шаардах тодорхой шалтгаан гараагүй; зөв peak гэдгийг батлаагүй.'))
    lines.append('Эх файл: '+p['file'])
    severe=bool(flags&{'PULLUP_SUSPECT','STUTTER_SUSPECT','PLUS_MINUS_A_SPACING','OFF_BIN','BELOW_RFU','ABOVE_RFU','LOW_HOMO_HEIGHT','IMBALANCED','REPLICATE_DISCORDANCE','REPLICATE_MISSING_CALL','OUTSIDE_MARKER','MARKER_AMBIGUOUS'})
    return '\n'.join(lines),severe


def native_snapshot_review(snapshot,profiles):
    """Read only accessible, current tables. No file I/O; no invented per-panel thresholds."""
    exports=[]
    for table in snapshot['tables']:
        buffer=io.StringIO();writer=csv.DictWriter(buffer,fieldnames=table['headers'],delimiter='\t',extrasaction='ignore')
        writer.writeheader();writer.writerows(table['rows'])
        exports.append(parse_export_text(buffer.getvalue(),'GeneMapper-live-table'))
    if not any(e['kind'] in ('genotypes','sizing') for e in exports):raise ValueError('GENOTYPE_TABLE_UNAVAILABLE: зөвхөн Samples хүснэгт харагдсан; peak-ийн дүгнэлт өгөөгүй.')
    result=add_replicate_checks(analyze_exports(exports,profiles,{}))
    alerts=[]
    by_identity={(s['file'],s['marker'],s['dye']):s for s in result['summaries']}
    reasons={'OFF_BIN':'Bin хүрээнд ороогүй','OUTSIDE_MARKER':'Маркерийн хэмжээний хүрээнээс гадуур',
        'BELOW_RFU':'Маркерийн RFU доод босгоос бага','ABOVE_RFU':'Маркерийн RFU дээд босгоос өндөр',
        'ALLELE_UNKNOWN':'Аллелийн нэр оноогдоогүй — шалгах',
        'REPLICATE_DISCORDANCE':'Ижил нэртэй дээжүүдийн allele зөрсөн — давталт/шошгыг шалгах',
        'REPLICATE_MISSING_CALL':'Ижил нэртэй дээжийн нэгэнд allele дуудлага дутуу',
        'DUPLICATE_ALLELE_PEAKS':'Ижил allele нэртэй олон peak байна'}
    for identity,row in by_identity.items():
        flags=set(row['flags']);why=[v for k,v in reasons.items() if k in flags]
        if row['genotype']=='MULTI_ALLELE_REVIEW':why.append('Хоёроос олон allele — panel-ийн хүлээгдсэн ploidy/холимгийг шалгах')
        if not why:continue
        alerts.append(dict(project=snapshot['project'],panel=result['samples'].get(row['file'],{}).get('panel',''),
                           sample=row['sample'] or row['file'],file=row['file'],marker=row['marker'],dye=row['dye'],
                           reason='; '.join(why),alleles=row['alleles']))
    return dict(project=snapshot['project'],alerts=alerts,rows=len(result['summaries']),
                peaks=len(result['peaks']),panels=sorted({r.get('panel','') for r in result['samples'].values() if r.get('panel')}),
                coverage='Native Java tables only; no arbitrary waveform access; no default stutter/pull-up/ploidy thresholds')


def tray_click_action(message, detail):
    """Decode only; Win32 callback must never invoke Tcl/Tk."""
    return 'open' if message==0x8012 and (int(detail)&0xffff) in (0x202,0x203,0x205,0x400,0x401) else None

def setup_diagnostics(directory, name='app'):
    import logging,logging.handlers,faulthandler,sys
    directory=Path(directory);directory.mkdir(parents=True,exist_ok=True)
    logger=logging.getLogger('PeakWatch.'+name);logger.setLevel(logging.INFO);logger.propagate=False
    if not logger.handlers:
        handler=logging.handlers.RotatingFileHandler(directory/(name+'.log'),maxBytes=262144,backupCount=1,encoding='utf-8')
        handler.setFormatter(logging.Formatter('%(asctime)s %(levelname)s %(message)s'));logger.addHandler(handler)
    fault=directory/(name+'-fault.log')
    if fault.exists() and fault.stat().st_size>262144:fault.replace(directory/(name+'-fault.previous.log'))
    handle=fault.open('a',encoding='utf-8')
    try:faulthandler.enable(handle,all_threads=True)
    except (RuntimeError,OSError):pass
    logger.info('Start 0.6.1 Python=%s pointer=%s',sys.version.split()[0],__import__('struct').calcsize('P')*8)
    return logger,handle
