"""Strict parser and limited review rules; no allele classification."""
import re
import math
from dataclasses import dataclass

@dataclass(frozen=True)
class Peak:
    point: int
    size: float
    height: float
    marker: str = ''
    allele: str = ''

def parse_status(text):
    # Do not parse axis X/Y coordinates or replace OCR-confused digits.
    match = re.search(r'\bPeak\s*:\s*Data\s+Point\s+(\d+)\s+Size\s+(\d+\.\d+)\s+Height\s+(\d+(?:\.\d+)?)(?=\s|\]|$)', text, re.I)
    if not match:
        return None
    point, size, height = int(match[1]), float(match[2]), float(match[3])
    if not (0 < point < 10000000 and 0 < size < 20000 and 0 <= height < 100000000):
        return None
    marker = re.search(r'\bMarker\s+([A-Za-z][A-Za-z0-9_*.-]*)', text)
    allele = re.search(r'\bAllele\s+([^\]\s]+)', text)
    return Peak(point, size, height, marker[1] if marker else '', allele[1] if allele else '')

def validate_rule(rule):
    for key in ('min_bp', 'max_bp', 'min_rfu', 'max_rfu'):
        val = rule.get(key)
        if val is not None and (not isinstance(val, (int, float)) or not math.isfinite(val) or val < 0):
            raise ValueError('Босго нь тэгээс багагүй тоо байх ёстой.')
    for a,b in [('min_bp','max_bp'),('min_rfu','max_rfu')]:
        if rule.get(a) is not None and rule.get(b) is not None and rule[a] > rule[b]:
            raise ValueError('Доод босго дээд босгоос их байна.')
    return rule

def review(peak, marker, rule):
    notes = []
    if not marker:
        return ['Маркер баталгаажаагүй: дүгнэлт өгөөгүй.']
    if peak.marker and peak.marker.casefold() != marker.casefold():
        return ['Маркер зөрсөн: тохиргоог энэ peak-д хэрэглээгүй.']
    if peak.allele == '?':
        notes.append('GeneMapper allele = ?: аллелийн нэр/bin-ийг шалгана уу.')
    if not rule or not any(rule.get(k) is not None for k in ('min_bp','max_bp','min_rfu','max_rfu')):
        notes.append('Баталгаажсан bp/RFU босго оруулаагүй: тоон шалгалт хийгдээгүй.')
        return notes
    validate_rule(rule)
    for key, value, predicate, label in [
        ('min_bp',peak.size,lambda x,y:x<y,'bp доод хязгаараас бага'),
        ('max_bp',peak.size,lambda x,y:x>y,'bp дээд хязгаараас их'),
        ('min_rfu',peak.height,lambda x,y:x<y,'RFU доод босгоос бага'),
        ('max_rfu',peak.height,lambda x,y:x>y,'RFU дээд босгоос их')]:
        if rule.get(key) is not None and predicate(value,rule[key]):
            notes.append(f'Сэжигтэй: {label} ({value:g}; босго {rule[key]:g}).')
    bins=rule.get('bins',[])
    if bins and not any(b['center']-b['left_offset'] <= peak.size <= b['center']+b['right_offset'] for b in bins):
        notes.append('Сэжигтэй: оруулсан BinSet-ийн bin хүрээнд орохгүй байна. BinSet-ээ шалгана уу.')
    return notes or ['Оруулсан bp/RFU босго зөрчөөгүй. Аллель зөв гэдгийг батлахгүй.']


def detect_panel(text, profiles):
    """Exact known panel tokens only; ambiguous header gives no context."""
    found={r.get('panel') for r in profiles.values() if r.get('panel') and
           re.search(r'(?<![A-Za-z0-9_])'+re.escape(r['panel'])+r'(?![A-Za-z0-9_])',text,re.I)}
    return next(iter(found)) if len(found)==1 else ''

def resolve_marker(peak, panel, profiles):
    """Never reuse a stale manual rule or guess among dyes/kits."""
    if not panel:return None, 'Panel танигдаагүй: маркер сонгоогүй.'
    candidates=[(k,r) for k,r in profiles.items() if r.get('panel','').casefold()==panel.casefold()]
    if peak.marker:
        candidates=[(k,r) for k,r in candidates if r.get('marker_name','').casefold()==peak.marker.casefold()]
    else:
        candidates=[(k,r) for k,r in candidates if r.get('min_bp') is not None and r.get('max_bp') is not None and r['min_bp']<=peak.size<=r['max_bp']]
    if len(candidates)==1:
        return candidates[0][0], ('Status маркераар автоматаар сонгосон.' if peak.marker else 'Panel + bp хүрээний цорын ганц маркер. Өнгө баталгаажаагүй.')
    return None, ('Олон маркер таарч байна: автоматаар сонгоогүй.' if candidates else 'Panel дотор тохирох маркер олдсонгүй.')
